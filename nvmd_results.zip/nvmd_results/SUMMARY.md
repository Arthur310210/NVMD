# NVMD reproduction — summary of the CPU-profile runs

## ECG

K*: NVMD(A) 3, NVMD(P) 3 (paper 3)

SNR_imp (dB) at K*, ours / paper:

| Method | -5 dB | -3 dB | -1 dB | 0 dB | 5 dB |
|---|---|---|---|---|---|
| best baseline | 11.70 (VMD-DWT-NLM) / 11.34 | 10.91 (VMD-DWT-NLM) / 10.83 | 9.88 (VMD-NLM) / 10.25 | 9.29 (VMD-NLM) / 9.38 | 7.41 (EMD-DWT-NLM) / 8.60 |
| NVMD(A) | 14.05 / 13.41 | 13.27 / 12.14 | 12.38 / 10.86 | 11.89 / 9.54 | 9.01 / 8.93 |
| NVMD(P) | 13.90 / 14.43 | 13.30 / 13.27 | 12.57 / 11.73 | 12.16 / 10.9 | 9.63 / 9.16 |

At -1 dB (Tables IV/V): DDAE [33] 10.74 dB (paper 9.01), DDAE-F3 (extra) 13.22 dB, NVMD(A) 12.38, NVMD(P) 12.57 dB.

## EEG

K*: NVMD(A) 4, NVMD(P) 4 (paper 5)

SNR_imp (dB) at K*, ours / paper:

| Method | -10 dB | -8 dB | -6 dB | -4 dB | -2 dB |
|---|---|---|---|---|---|
| best baseline | 5.06 (VMD-DWT-NLM) / 8.88 | 4.82 (VMD-NLM) / 8.68 | 4.44 (VMD-NLM) / 7.88 | 4.00 (VMD-NLM) / 7.68 | 3.35 (VMD-NLM) / 6.98 |
| NVMD(A) | 11.72 / 12.81 | 10.39 / 11.98 | 9.07 / 10.48 | 7.76 / 9.42 | 6.48 / 9.12 |
| NVMD(P) | 11.72 / 13.92 | 10.38 / 12.12 | 9.05 / 11.04 | 7.73 / 9.83 | 6.41 / 9.53 |

At -6 dB (Tables IV/V): DDAE [33] 7.80 dB (paper 9.53), DDAE-F3 (extra) 9.06 dB, NVMD(A) 9.07, NVMD(P) 9.05 dB.

## SEMG (synthetic stand-in, not Ninapro)

K*: NVMD(A) 4, NVMD(P) 3 (paper 4)

SNR_imp (dB) at K*, ours / paper:

| Method | -14 dB | -10 dB | -6 dB | -2 dB | 2 dB |
|---|---|---|---|---|---|
| best baseline | 10.82 (VMD-DWT-NLM) / 10.36 | 9.96 (VMD-DWT-NLM) / 8.57 | 8.44 (VMD-NLM) / 7.41 | 6.01 (VMD-NLM) / 6.14 | 4.07 (VMD-DWT) / 4.93 |
| NVMD(A) | 14.51 / 15.48 | 11.45 / 12.91 | 8.74 / 10.54 | 6.29 / 8.78 | 3.70 / 6.12 |
| NVMD(P) | 14.50 / 16.23 | 11.48 / 13.57 | 8.87 / 11.32 | 6.64 / 9.56 | 4.31 / 6.39 |

At -6 dB (Tables IV/V): DDAE [33] 6.56 dB (paper 9.11), DDAE-F3 (extra) 8.88 dB, NVMD(A) 8.74, NVMD(P) 8.87 dB.

## ECG: does NVMD(P)'s lead over NVMD(A) grow with more training data? (K = 3)

| input SNR | P−A, 6,000 train | P−A, 18,000 train |
|---|---|---|
| -5 dB | -0.15 dB | +0.25 dB |
| -3 dB | +0.03 dB | +0.30 dB |
| -1 dB | +0.19 dB | +0.34 dB |
| 0 dB | +0.26 dB | +0.37 dB |
| 5 dB | +0.61 dB | +0.49 dB |

