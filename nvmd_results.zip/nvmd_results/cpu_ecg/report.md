# NVMD reproduction report — ECG

Profile: cpu | training fragments: 6000 | epochs: 20 | K = 1..6 | test fragments: 1500 (NVMD/DDAE), 100 (baselines) per SNR.

Each cell is **ours / paper**. K* is chosen per method by Eq. (23), pooling SNR_imp over the table's SNR columns.

## Paper claims checked on our numbers

| Claim (Section IV-C) | Holds? | Detail |
|---|---|---|
| NVMD(P) > NVMD(A) (SNR_imp, every table SNR) | no | P−A = -0.15, +0.03, +0.19, +0.26, +0.61 dB |
| NVMD(A) > best baseline (every table SNR) | yes | A−best = +2.34, +2.36, +2.50, +2.60, +1.60 dB |
| NVMD(P) lowest RMSE (every table SNR) | no | P−best = +0.014, +0.004, -0.007, -0.013, +0.008 |
| VMD hybrids > EMD/EEMD hybrids | no | best VMD − best (E)EMD = +1.20, +0.96, +0.54, +0.28, -1.66 dB |
| NVMD faster than VMD hybrids; A faster than P | no | A 7.2, P 21.3, fastest VMD hybrid 6.7 ms/data |
| NVMD(A) at K* > DDAE (FCN-DAE [33]) (-1 dB) | yes | 12.38 vs 10.74 dB |
| NVMD(P) at K* > DDAE (FCN-DAE [33]) (-1 dB) | yes | 12.57 vs 10.74 dB |
| NVMD(A) at K* > DDAE-F3 (Fig. 3 backbone, extra) (-1 dB) | no | 12.38 vs 13.22 dB |
| NVMD(P) at K* > DDAE-F3 (Fig. 3 backbone, extra) (-1 dB) | no | 12.57 vs 13.22 dB |
| K* = 3 | yes | NVMD(A) K*=3, NVMD(P) K*=3 |

## Table I — average computation time T_IMFs (ms/data, batch size 1, mean over K = 1..6; ours on a 2-core CPU)

| Method | ours | paper |
|---|---|---|
| EMD-DWT | 4.00 | 15.4 |
| EMD-NLM | 8.12 | 73.1 |
| EMD-DWT-NLM | 8.32 | 65.5 |
| EEMD-DWT | 153.86 | 717 |
| EEMD-NLM | 157.98 | 754 |
| EEMD-DWT-NLM | 158.30 | 741 |
| VMD-DWT | 6.66 | 70 |
| VMD-NLM | 10.74 | 101 |
| VMD-DWT-NLM | 11.03 | 143 |
| NVMD(A) | 7.21 | 4.7 |
| NVMD(P) | 21.29 | 9.7 |

## Table II — average SNR_imp (dB) at K* (columns = input SNR in dB)

| Method | K* | -5 dB | -3 dB | -1 dB | 0 dB | 5 dB |
|---|---|---|---|---|---|---|
| EMD-DWT | 1 | 10.50 / 5.93 | 9.94 / 5.86 | 9.33 / 5.76 | 9.01 / 5.56 | 7.41 / 5.33 |
| EMD-NLM | 1 | 9.55 / 2.74 | 9.12 / 1.98 | 8.68 / 1.15 | 8.48 / 0.756 | 7.39 / -1.32 |
| EMD-DWT-NLM | 1 | 10.50 / 3.83 | 9.94 / 2.36 | 9.34 / 1.75 | 9.01 / 1.13 | 7.41 / 0.953 |
| EEMD-DWT | 1 | 10.50 / 6.36 | 9.94 / 6.13 | 9.33 / 6.02 | 9.01 / 5.95 | 7.41 / 5.86 |
| EEMD-NLM | 1 | 9.55 / 3.21 | 9.12 / 2.56 | 8.68 / 1.46 | 8.48 / 0.983 | 7.39 / 0.153 |
| EEMD-DWT-NLM | 1 | 10.50 / 4.91 | 9.94 / 4.03 | 9.34 / 3.21 | 9.01 / 2.53 | 7.41 / 1.56 |
| VMD-DWT | 1 | 11.70 / 11.34 | 10.90 / 10.83 | 9.87 / 10.25 | 9.28 / 9.38 | 5.74 / 8.6 |
| VMD-NLM | 1 | 11.69 / 9.41 | 10.90 / 9.23 | 9.88 / 9.02 | 9.29 / 8.57 | 5.76 / 7.25 |
| VMD-DWT-NLM | 1 | 11.70 / 10.52 | 10.91 / 9.91 | 9.88 / 9.54 | 9.29 / 9.04 | 5.74 / 7.83 |
| NVMD(A) | 3 | 14.05 / 13.41 | 13.27 / 12.14 | 12.38 / 10.86 | 11.89 / 9.54 | 9.01 / 8.93 |
| NVMD(P) | 3 | 13.90 / 14.43 | 13.30 / 13.27 | 12.57 / 11.73 | 12.16 / 10.9 | 9.63 / 9.16 |

## Table III — average RMSE at K* (columns = input SNR in dB)

| Method | K* | -5 dB | -3 dB | -1 dB | 0 dB | 5 dB |
|---|---|---|---|---|---|---|
| EMD-DWT | 1 | 0.427 / 0.391 | 0.361 / 0.402 | 0.307 / 0.419 | 0.284 / 0.445 | 0.192 / 0.483 |
| EMD-NLM | 1 | 0.472 / 0.794 | 0.393 / 0.913 | 0.328 / 0.963 | 0.299 / 0.998 | 0.189 / 1.45 |
| EMD-DWT-NLM | 1 | 0.427 / 0.596 | 0.361 / 0.843 | 0.307 / 0.874 | 0.284 / 0.923 | 0.192 / 0.984 |
| EEMD-DWT | 1 | 0.427 / 0.222 | 0.361 / 0.251 | 0.307 / 0.354 | 0.284 / 0.387 | 0.192 / 0.41 |
| EEMD-NLM | 1 | 0.472 / 0.732 | 0.393 / 0.824 | 0.328 / 0.891 | 0.299 / 0.957 | 0.189 / 1.23 |
| EEMD-DWT-NLM | 1 | 0.427 / 0.621 | 0.361 / 0.714 | 0.307 / 0.803 | 0.284 / 0.852 | 0.192 / 0.921 |
| VMD-DWT | 1 | 0.373 / 0.038 | 0.325 / 0.04 | 0.291 / 0.051 | 0.278 / 0.072 | 0.240 / 0.081 |
| VMD-NLM | 1 | 0.374 / 0.075 | 0.324 / 0.082 | 0.290 / 0.091 | 0.278 / 0.115 | 0.239 / 0.164 |
| VMD-DWT-NLM | 1 | 0.373 / 0.052 | 0.324 / 0.061 | 0.291 / 0.063 | 0.278 / 0.067 | 0.240 / 0.081 |
| NVMD(A) | 3 | 0.379 / 0.015 | 0.328 / 0.025 | 0.288 / 0.036 | 0.270 / 0.053 | 0.209 / 0.069 |
| NVMD(P) | 3 | 0.387 / 0.002 | 0.329 / 0.017 | 0.284 / 0.032 | 0.265 / 0.039 | 0.197 / 0.058 |

## Table IV — per-IMF correlation at input SNR -1 dB

| Model | K | per-IMF ours | per-IMF paper | overall ours | overall paper |
|---|---|---|---|---|---|
| DDAE (FCN-DAE [33]) | – | – | – | 0.792 | 0.935 |
| DDAE-F3 (Fig. 3 backbone, our extra) | – | – | – | 0.875 | — |
| NVMD(A) | 1 | 0.884 | 0.954 | 0.801 | 0.938 |
| NVMD(A) | 2 | 0.865, 0.727 | 0.958, 0.893 | 0.856 | 0.946 |
| NVMD(A) | 3 | 0.843, 0.723, 0.581 | 0.959, 0.962, 0.883 | 0.862 | 0.958 |
| NVMD(A) | 4 | 0.812, 0.730, 0.610, 0.420 | 0.948, 0.953, 0.873, 0.843 | 0.856 | 0.937 |
| NVMD(A) | 5 | 0.799, 0.731, 0.595, 0.456, 0.251 | — | 0.853 | — |
| NVMD(A) | 6 | 0.789, 0.720, 0.581, 0.463, 0.335, 0.147 | — | 0.853 | — |
| NVMD(P) | 1 | 0.878 | 0.954 | 0.797 | 0.938 |
| NVMD(P) | 2 | 0.852, 0.713 | 0.958, 0.893 | 0.844 | 0.946 |
| NVMD(P) | 3 | 0.827, 0.721, 0.579 | 0.959, 0.962, 0.883 | 0.855 | 0.958 |
| NVMD(P) | 4 | 0.822, 0.719, 0.607, 0.423 | 0.948, 0.953, 0.873, 0.843 | 0.858 | 0.937 |
| NVMD(P) | 5 | 0.804, 0.735, 0.604, 0.470, 0.306 | — | 0.863 | — |
| NVMD(P) | 6 | 0.785, 0.722, 0.592, 0.490, 0.334, 0.167 | — | 0.858 | — |

## Table V — per-IMF SNR_imp (dB) at input SNR -1 dB

| Model | K | per-IMF ours | per-IMF paper | overall ours | overall paper |
|---|---|---|---|---|---|
| DDAE (FCN-DAE [33]) | – | – | – | 10.742 | 9.01 |
| DDAE-F3 (Fig. 3 backbone, our extra) | – | – | – | 13.220 | — |
| NVMD(A) | 1 | 14.436 | 13.32 | 10.400 | 9.12 |
| NVMD(A) | 2 | 14.400, 6.069 | 12.81, 3.61 | 12.111 | 10.83 |
| NVMD(A) | 3 | 14.298, 5.586, 2.871 | 13.23, 3.83, 0.89 | 12.378 | 11.3 |
| NVMD(A) | 4 | 14.378, 5.561, 3.954, 1.230 | 12.02, 2.61, 0.76, -1.53 | 12.334 | 10.58 |
| NVMD(A) | 5 | 14.678, 5.244, 3.949, 2.093, 0.688 | — | 12.171 | — |
| NVMD(A) | 6 | 14.644, 4.823, 3.564, 2.105, 1.249, 0.657 | — | 12.104 | — |
| NVMD(P) | 1 | 14.538 | 13.32 | 10.455 | 9.12 |
| NVMD(P) | 2 | 14.238, 6.026 | 12.81, 3.61 | 11.973 | 10.83 |
| NVMD(P) | 3 | 14.163, 5.506, 2.323 | 13.23, 3.83, 0.89 | 12.567 | 11.3 |
| NVMD(P) | 4 | 14.711, 5.321, 4.207, 1.717 | 12.02, 2.61, 0.76, -1.53 | 12.443 | 10.58 |
| NVMD(P) | 5 | 14.801, 5.233, 3.969, 2.197, -0.136 | — | 12.514 | — |
| NVMD(P) | 6 | 14.601, 4.839, 3.521, 2.168, 0.444, -3.679 | — | 12.238 | — |

## Optimal number of IMFs K*

Paper: K* = 3 for NVMD. Ours: NVMD(A): 3, NVMD(P): 3, EMD-DWT: 1, EMD-NLM: 1, EMD-DWT-NLM: 1, EEMD-DWT: 1, EEMD-NLM: 1, EEMD-DWT-NLM: 1, VMD-DWT: 1, VMD-NLM: 1, VMD-DWT-NLM: 1
