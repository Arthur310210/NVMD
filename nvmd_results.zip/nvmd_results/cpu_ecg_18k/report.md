# NVMD reproduction report — ECG

Profile: cpu | training fragments: 18000 | epochs: 20 | K = 1..3 | test fragments: 1500 (NVMD/DDAE), 100 (baselines) per SNR.

Each cell is **ours / paper**. K* is chosen per method by Eq. (23), pooling SNR_imp over the table's SNR columns.

## Paper claims checked on our numbers

| Claim (Section IV-C) | Holds? | Detail |
|---|---|---|
| NVMD(P) > NVMD(A) (SNR_imp, every table SNR) | yes | P−A = +0.25, +0.30, +0.34, +0.37, +0.49 dB |
| NVMD(A) at K* > DDAE (FCN-DAE [33]) (-1 dB) | yes | 12.76 vs 11.58 dB |
| NVMD(P) at K* > DDAE (FCN-DAE [33]) (-1 dB) | yes | 13.10 vs 11.58 dB |
| NVMD(A) at K* > DDAE-F3 (Fig. 3 backbone, extra) (-1 dB) | no | 12.76 vs 13.75 dB |
| NVMD(P) at K* > DDAE-F3 (Fig. 3 backbone, extra) (-1 dB) | no | 13.10 vs 13.75 dB |
| K* = 3 | yes | NVMD(A) K*=3, NVMD(P) K*=3 |

## Table I — average computation time T_IMFs (ms/data, batch size 1, mean over K = 1..3; ours on a 2-core CPU)

| Method | ours | paper |
|---|---|---|
| NVMD(A) | 3.80 | 4.7 |
| NVMD(P) | 14.28 | 9.7 |

## Table II — average SNR_imp (dB) at K* (columns = input SNR in dB)

| Method | K* | -5 dB | -3 dB | -1 dB | 0 dB | 5 dB |
|---|---|---|---|---|---|---|
| NVMD(A) | 3 | 14.36 / 13.41 | 13.59 / 12.14 | 12.76 / 10.86 | 12.31 / 9.54 | 9.65 / 8.93 |
| NVMD(P) | 3 | 14.61 / 14.43 | 13.89 / 13.27 | 13.10 / 11.73 | 12.68 / 10.9 | 10.14 / 9.16 |

## Table III — average RMSE at K* (columns = input SNR in dB)

| Method | K* | -5 dB | -3 dB | -1 dB | 0 dB | 5 dB |
|---|---|---|---|---|---|---|
| NVMD(A) | 3 | 0.365 / 0.015 | 0.316 / 0.025 | 0.276 / 0.036 | 0.258 / 0.053 | 0.194 / 0.069 |
| NVMD(P) | 3 | 0.357 / 0.002 | 0.307 / 0.017 | 0.265 / 0.032 | 0.247 / 0.039 | 0.183 / 0.058 |

## Table IV — per-IMF correlation at input SNR -1 dB

| Model | K | per-IMF ours | per-IMF paper | overall ours | overall paper |
|---|---|---|---|---|---|
| DDAE (FCN-DAE [33]) | – | – | – | 0.819 | 0.935 |
| DDAE-F3 (Fig. 3 backbone, our extra) | – | – | – | 0.883 | — |
| NVMD(A) | 1 | 0.891 | 0.954 | 0.808 | 0.938 |
| NVMD(A) | 2 | 0.874, 0.746 | 0.958, 0.893 | 0.862 | 0.946 |
| NVMD(A) | 3 | 0.855, 0.750, 0.613 | 0.959, 0.962, 0.883 | 0.868 | 0.958 |
| NVMD(P) | 1 | 0.890 | 0.954 | 0.809 | 0.938 |
| NVMD(P) | 2 | 0.874, 0.746 | 0.958, 0.893 | 0.862 | 0.946 |
| NVMD(P) | 3 | 0.852, 0.754, 0.619 | 0.959, 0.962, 0.883 | 0.871 | 0.958 |

## Table V — per-IMF SNR_imp (dB) at input SNR -1 dB

| Model | K | per-IMF ours | per-IMF paper | overall ours | overall paper |
|---|---|---|---|---|---|
| DDAE (FCN-DAE [33]) | – | – | – | 11.584 | 9.01 |
| DDAE-F3 (Fig. 3 backbone, our extra) | – | – | – | 13.750 | — |
| NVMD(A) | 1 | 14.973 | 13.32 | 10.834 | 9.12 |
| NVMD(A) | 2 | 15.206, 7.099 | 12.81, 3.61 | 12.521 | 10.83 |
| NVMD(A) | 3 | 14.803, 6.413, 4.414 | 13.23, 3.83, 0.89 | 12.756 | 11.3 |
| NVMD(P) | 1 | 14.945 | 13.32 | 10.836 | 9.12 |
| NVMD(P) | 2 | 15.018, 7.062 | 12.81, 3.61 | 12.558 | 10.83 |
| NVMD(P) | 3 | 15.001, 6.583, 3.931 | 13.23, 3.83, 0.89 | 13.101 | 11.3 |

## Optimal number of IMFs K*

Paper: K* = 3 for NVMD. Ours: NVMD(A): 3, NVMD(P): 3
