# NVMD reproduction report — SEMG

Profile: cpu | training fragments: 3000 | epochs: 15 | K = 1..5 | test fragments: 600 (NVMD/DDAE), 30 (baselines) per SNR.

Each cell is **ours / paper**. K* is chosen per method by Eq. (23), pooling SNR_imp over the table's SNR columns.

## Paper claims checked on our numbers

| Claim (Section IV-C) | Holds? | Detail |
|---|---|---|
| NVMD(P) > NVMD(A) (SNR_imp, every table SNR) | no | P−A = -0.00, +0.03, +0.13, +0.35, +0.61 dB |
| NVMD(A) > best baseline (every table SNR) | no | A−best = +3.68, +1.49, +0.30, +0.28, -0.37 dB |
| NVMD(P) lowest RMSE (every table SNR) | no | P−best = -0.188, +0.023, +0.088, +0.056, +0.058 |
| VMD hybrids > EMD/EEMD hybrids | yes | best VMD − best (E)EMD = +0.32, +0.99, +1.13, +0.85, +0.58 dB |
| NVMD faster than VMD hybrids; A faster than P | yes | A 8.7, P 21.2, fastest VMD hybrid 28.2 ms/data |
| NVMD(A) at K* > DDAE (FCN-DAE [33]) (-6 dB) | yes | 8.74 vs 6.56 dB |
| NVMD(P) at K* > DDAE (FCN-DAE [33]) (-6 dB) | yes | 8.87 vs 6.56 dB |
| NVMD(A) at K* > DDAE-F3 (Fig. 3 backbone, extra) (-6 dB) | no | 8.74 vs 8.88 dB |
| NVMD(P) at K* > DDAE-F3 (Fig. 3 backbone, extra) (-6 dB) | no | 8.87 vs 8.88 dB |
| K* = 4 | no | NVMD(A) K*=4, NVMD(P) K*=3 |

## Table I — average computation time T_IMFs (ms/data, batch size 1, mean over K = 1..5; ours on a 2-core CPU)

| Method | ours | paper |
|---|---|---|
| EMD-DWT | 10.45 | 65 |
| EMD-NLM | 19.47 | 301 |
| EMD-DWT-NLM | 20.78 | 285 |
| EEMD-DWT | 199.48 | 2861 |
| EEMD-NLM | 208.73 | 3015 |
| EEMD-DWT-NLM | 210.59 | 2984 |
| VMD-DWT | 28.15 | 268 |
| VMD-NLM | 36.70 | 523 |
| VMD-DWT-NLM | 38.66 | 587 |
| NVMD(A) | 8.69 | 24.2 |
| NVMD(P) | 21.18 | 43.3 |

## Table II — average SNR_imp (dB) at K* (columns = input SNR in dB)

| Method | K* | -14 dB | -10 dB | -6 dB | -2 dB | 2 dB |
|---|---|---|---|---|---|---|
| EMD-DWT | 1 | 10.30 / 8.21 | 8.64 / 6.03 | 6.16 / 4.24 | 3.28 / 3.52 | 0.52 / 2.92 |
| EMD-NLM | 1 | 10.51 / 7.03 | 8.97 / 5.12 | 7.04 / 3.4 | 5.10 / 2.11 | 3.49 / 1.08 |
| EMD-DWT-NLM | 1 | 10.31 / 6.45 | 8.64 / 4.98 | 6.16 / 2.76 | 3.28 / 1.35 | 0.51 / 0.13 |
| EEMD-DWT | 2 | 9.94 / 8.93 | 8.91 / 6.35 | 7.31 / 4.98 | 5.16 / 4.03 | 2.45 / 3.25 |
| EEMD-NLM | 1 | 10.51 / 7.96 | 8.97 / 6.01 | 7.04 / 4.06 | 5.10 / 2.87 | 3.49 / 1.36 |
| EEMD-DWT-NLM | 2 | 9.95 / 6.23 | 8.91 / 5.86 | 7.31 / 4.22 | 5.15 / 3.05 | 2.44 / 1.57 |
| VMD-DWT | 2 | 10.76 / 10.36 | 9.94 / 8.57 | 8.42 / 7.41 | 5.95 / 6.14 | 4.07 / 4.93 |
| VMD-NLM | 1 | 10.70 / 8.94 | 9.90 / 7.2 | 8.44 / 6.22 | 6.01 / 4.85 | 2.83 / 3.94 |
| VMD-DWT-NLM | 2 | 10.82 / 8.23 | 9.96 / 7.06 | 8.42 / 5.98 | 5.93 / 4.99 | 3.98 / 4.15 |
| NVMD(A) | 4 | 14.51 / 15.48 | 11.45 / 12.91 | 8.74 / 10.54 | 6.29 / 8.78 | 3.70 / 6.12 |
| NVMD(P) | 3 | 14.50 / 16.23 | 11.48 / 13.57 | 8.87 / 11.32 | 6.64 / 9.56 | 4.31 / 6.39 |

## Table III — average RMSE at K* (columns = input SNR in dB)

| Method | K* | -14 dB | -10 dB | -6 dB | -2 dB | 2 dB |
|---|---|---|---|---|---|---|
| EMD-DWT | 1 | 0.986 / 0.933 | 0.755 / 1.98 | 0.635 / 2.58 | 0.560 / 3.49 | 0.487 / 3.84 |
| EMD-NLM | 1 | 0.980 / 2.94 | 0.735 / 4.98 | 0.581 / 6.13 | 0.458 / 7.08 | 0.349 / 9.32 |
| EMD-DWT-NLM | 1 | 0.985 / 3.21 | 0.754 / 3.87 | 0.635 / 4.56 | 0.560 / 6.98 | 0.488 / 8.45 |
| EEMD-DWT | 2 | 1.031 / 0.846 | 0.733 / 0.981 | 0.557 / 1.45 | 0.450 / 2.32 | 0.387 / 2.87 |
| EEMD-NLM | 1 | 0.980 / 1.56 | 0.735 / 2.34 | 0.581 / 3.31 | 0.458 / 4.23 | 0.349 / 5.32 |
| EEMD-DWT-NLM | 2 | 1.030 / 1.84 | 0.733 / 2.95 | 0.557 / 4.36 | 0.450 / 5.85 | 0.387 / 7.02 |
| VMD-DWT | 2 | 0.945 / 0.657 | 0.654 / 0.723 | 0.490 / 0.815 | 0.411 / 0.874 | 0.318 / 0.921 |
| VMD-NLM | 1 | 0.951 / 0.832 | 0.656 / 0.924 | 0.488 / 1.35 | 0.407 / 1.89 | 0.371 / 3.21 |
| VMD-DWT-NLM | 2 | 0.937 / 0.942 | 0.652 / 1.34 | 0.490 / 1.97 | 0.412 / 2.53 | 0.322 / 3.01 |
| NVMD(A) | 4 | 0.749 / 0.278 | 0.677 / 0.487 | 0.581 / 0.543 | 0.474 / 0.678 | 0.389 / 0.861 |
| NVMD(P) | 3 | 0.749 / 0.253 | 0.674 / 0.421 | 0.576 / 0.524 | 0.464 / 0.619 | 0.375 / 0.825 |

## Table IV — per-IMF correlation at input SNR -6 dB

| Model | K | per-IMF ours | per-IMF paper | overall ours | overall paper |
|---|---|---|---|---|---|
| DDAE (FCN-DAE [33]) | – | – | – | 0.354 | 0.955 |
| DDAE-F3 (Fig. 3 backbone, our extra) | – | – | – | 0.693 | — |
| NVMD(A) | 1 | 0.762 | 0.923 | 0.640 | 0.904 |
| NVMD(A) | 2 | 0.771, 0.641 | 0.943, 0.89 | 0.683 | 0.928 |
| NVMD(A) | 3 | 0.752, 0.708, 0.416 | 0.951, 0.94, 0.887 | 0.682 | 0.942 |
| NVMD(A) | 4 | 0.743, 0.723, 0.571, 0.302 | 0.975, 0.946, 0.901, 0.883 | 0.688 | 0.966 |
| NVMD(A) | 5 | 0.725, 0.712, 0.440, 0.010, 0.000 | 0.952, 0.936, 0.903, 0.863, 0.842 | 0.640 | 0.948 |
| NVMD(P) | 1 | 0.764 | 0.923 | 0.641 | 0.904 |
| NVMD(P) | 2 | 0.769, 0.646 | 0.943, 0.89 | 0.685 | 0.928 |
| NVMD(P) | 3 | 0.756, 0.712, 0.490 | 0.951, 0.94, 0.887 | 0.694 | 0.942 |
| NVMD(P) | 4 | 0.737, 0.719, 0.559, 0.246 | 0.975, 0.946, 0.901, 0.883 | 0.679 | 0.966 |
| NVMD(P) | 5 | 0.734, 0.715, 0.597, 0.439, 0.196 | 0.952, 0.936, 0.903, 0.863, 0.842 | 0.692 | 0.948 |

## Table V — per-IMF SNR_imp (dB) at input SNR -6 dB

| Model | K | per-IMF ours | per-IMF paper | overall ours | overall paper |
|---|---|---|---|---|---|
| DDAE (FCN-DAE [33]) | – | – | – | 6.555 | 9.11 |
| DDAE-F3 (Fig. 3 backbone, our extra) | – | – | – | 8.877 | — |
| NVMD(A) | 1 | 9.782 | 11.34 | 8.113 | 8.93 |
| NVMD(A) | 2 | 9.866, 8.186 | 10.87, 7.98 | 8.680 | 10.12 |
| NVMD(A) | 3 | 9.578, 8.962, 6.818 | 12.48, 9.44, 4.87 | 8.741 | 10.57 |
| NVMD(A) | 4 | 9.503, 9.264, 7.689, 6.277 | 15.11, 13.45, 8.36, 3.54 | 8.744 | 11.53 |
| NVMD(A) | 5 | 9.254, 9.122, 6.974, 5.922, 5.942 | 14.31, 13.17, 9.87, 4.31, 2.93 | 8.188 | 9.86 |
| NVMD(P) | 1 | 9.802 | 11.34 | 8.167 | 8.93 |
| NVMD(P) | 2 | 9.948, 8.341 | 10.87, 7.98 | 8.700 | 10.12 |
| NVMD(P) | 3 | 9.692, 9.124, 7.132 | 12.48, 9.44, 4.87 | 8.874 | 10.57 |
| NVMD(P) | 4 | 9.339, 9.234, 7.628, 5.990 | 15.11, 13.45, 8.36, 3.54 | 8.714 | 11.53 |
| NVMD(P) | 5 | 9.369, 9.245, 7.911, 6.860, 6.079 | 14.31, 13.17, 9.87, 4.31, 2.93 | 8.851 | 9.86 |

## Optimal number of IMFs K*

Paper: K* = 4 for NVMD. Ours: NVMD(A): 4, NVMD(P): 3, EMD-DWT: 1, EMD-NLM: 1, EMD-DWT-NLM: 1, EEMD-DWT: 2, EEMD-NLM: 1, EEMD-DWT-NLM: 2, VMD-DWT: 2, VMD-NLM: 1, VMD-DWT-NLM: 2
