import numpy as np, sys, json
from PIL import Image
def digitize(path, box, npts, blue=(0,114,189), tol=90):
    im = np.asarray(Image.open(path).convert('RGB')).astype(int)
    x0, x1, y0, y1 = box
    sub = im[y0+1:y1, x0+1:x1]
    d = np.sqrt(((sub - np.array(blue))**2).sum(2))
    m = d < tol
    xs, ys = [], []
    for j in range(sub.shape[1]):
        r = np.where(m[:, j])[0]
        if len(r): xs.append(j + x0 + 1); ys.append(r.mean() + y0 + 1)
    xs, ys = np.array(xs, float), np.array(ys, float)
    # grid lines: rows with many light-gray pixels (not white, not blue)
    g = ((sub.min(2) > 200) & (sub.max(2) < 245)).sum(1)
    grid = [i + y0 + 1 for i in range(len(g)) if g[i] > 0.4 * sub.shape[1]]
    t = (xs - x0) / (x1 - x0) * npts
    tt = np.arange(npts)
    yy = np.interp(tt, t, ys)
    return yy, grid, len(xs) / (x1 - x0 - 1)
out = {}
for name, f, box, n in (("ecg_a", "fig-000.png", (250, 891, 70, 139), 256),
                        ("ecg_b", "fig-000.png", (1095, 1737, 70, 139), 256),
                        ("eeg_a", "fig-001.png", (250, 891, 70, 130), 512),
                        ("eeg_b", "fig-001.png", (1095, 1737, 70, 130), 512),
                        ("emg_a", "fig-002.png", (250, 891, 83, 147), 512),
                        ("emg_b", "fig-002.png", (1095, 1737, 83, 147), 512)):
    yy, grid, cov = digitize("paperfigs/" + f, box, n)
    out[name] = dict(ypix=yy.tolist(), grid=grid, box=box)
    print(name, "coverage", round(cov, 3), "grid rows", grid)
json.dump(out, open("digitized.json", "w"))
