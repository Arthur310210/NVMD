"""Reproduce Section IV of the NVMD paper for one modality.

Examples
--------
  # full paper protocol (GPU strongly recommended)
  python scripts/run_experiment.py --dataset ecg  --data-root data/mitdb --download --out results/ecg
  python scripts/run_experiment.py --dataset eeg  --data-root data/eeg   --download --out results/eeg
  python scripts/run_experiment.py --dataset semg --data-root data/ninapro_db2 --out results/semg

  # fast smoke test (tiny subsets, 2 epochs, K up to 4)
  python scripts/run_experiment.py --dataset ecg --data-root data/mitdb --quick --out results/quick_ecg
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from nvmd.experiment import run  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True, choices=["ecg", "eeg", "semg"])
    ap.add_argument("--data-root", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--download", action="store_true", help="download MIT-BIH / EEGdenoiseNet first")
    ap.add_argument("--quick", action="store_true", help="tiny smoke-test configuration")
    ap.add_argument("--profile", choices=["paper", "cpu"], default="paper",
                    help="paper = full protocol; cpu = subsets/fewer epochs for a 2-core CPU")
    ap.add_argument("--threads", type=int)
    ap.add_argument("--synthetic-semg", action="store_true", help="surrogate sEMG (smoke tests only)")
    ap.add_argument("--skip-baselines", action="store_true")
    ap.add_argument("--device", default=None)
    ap.add_argument("--epochs", type=int)
    ap.add_argument("--batch-size", type=int)
    ap.add_argument("--K-max", type=int)
    ap.add_argument("--baseline-max-test", type=int)
    ap.add_argument("--eemd-trials", type=int)
    ap.add_argument("--n-train", type=int, help="override training-set size (with --profile cpu)")
    a = ap.parse_args()
    run(a.dataset, a.data_root, a.out, quick=a.quick, device=a.device, synthetic=a.synthetic_semg,
        skip_baselines=a.skip_baselines, do_download=a.download,
        profile=None if a.profile == "paper" else a.profile, threads=a.threads,
        overrides=dict(epochs=a.epochs, batch_size=a.batch_size, K_max=a.K_max,
                       baseline_max_test=a.baseline_max_test, eemd_trials=a.eemd_trials,
                       n_train=a.n_train))


if __name__ == "__main__":
    main()
