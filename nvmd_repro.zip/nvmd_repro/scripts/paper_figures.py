"""Redraw Figs. 7-9 in the paper's layout and style, from real model outputs.

Example signals
---------------
* ECG (Fig. 7): the paper's own clean segment. Digitizing Fig. 7(a) and searching all 48
  MIT-BIH records at every offset finds record 213, samples 16960-17215 (correlation 0.999,
  amplitude in mV). Our main ECG models never trained or validated on any fragment overlapping
  this window, so it is unseen data. WGN is added at exactly -1 dB (fixed seed).
* EEG (Fig. 8): the paper's epoch (EEGdenoiseNet #3673, corr 0.976) is in our training split, so
  we use the *test* epoch whose clean waveform correlates best with the paper's Fig. 8(a), with
  that test fragment's own artifact + WGN noise at -5 dB. Amplitudes are shown on the paper's
  scale (EEGdenoiseNet units / 1069, the factor that maps epoch #3673 onto Fig. 8(a)).
* sEMG (Fig. 9): synthetic stand-in (Ninapro DB2 unavailable). First 512 samples of the 2000-sample
  test fragment shown (as the paper's x-axis), amplitude rescaled for display to the paper's range.

Selection never looks at any denoising result; each method is shown at its own K* from the run.
"""
import argparse
import json
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from nvmd import baselines as BL  # noqa: E402
from nvmd.config import DATASETS, VMD  # noqa: E402
from nvmd.data import corrupt, scale_noise  # noqa: E402
from nvmd.metrics import snr_db  # noqa: E402
from nvmd.models import NVMDSystem  # noqa: E402
from nvmd.train import AMP, predict  # noqa: E402

ORDER = ["EMD-DWT", "EMD-NLM", "EMD-DWT-NLM", "EEMD-DWT", "EEMD-NLM", "EEMD-DWT-NLM",
         "VMD-DWT", "VMD-NLM", "VMD-DWT-NLM", "NVMD(P)"]
TRACES = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "nvmd", "paper_traces.npz")
EEG_DISPLAY = 1 / 1069.0
ECG_SOURCE = ("213", 16960)


def load_system(run, kind="P"):
    R = json.load(open(os.path.join(run, "results.json")))
    sysm = NVMDSystem(kind, R["K_max"])
    for c in range(1, R["K_max"] + 1):
        p = os.path.join(run, "ckpt", f"nvmd{kind}_col{c}.pt")
        sysm.trainable_module(c).load_state_dict(torch.load(p, map_location="cpu"))
    return sysm.eval(), R


def splits_of(run):
    import glob
    z = np.load(glob.glob(os.path.join(run, "cache", "splits_*.npz"))[0])
    return {s: {k: z[f"{s}_{k}"] for k in ("clean", "idx", "noise", "snr")} for s in ("train", "val", "test")}


def ncc(a, b):
    a = (a - a.mean()) / a.std()
    b = (b - b.mean(-1, keepdims=True)) / b.std(-1, keepdims=True)
    return b @ a / len(a)


def example(ds, run, data_root):
    """Returns clean, noisy (1-D, original units), display scale, description."""
    P = np.load(TRACES)
    snr = DATASETS[ds]["wave_snr"]
    if ds == "ecg":
        import wfdb
        rec, start = ECG_SOURCE
        x = wfdb.rdrecord(os.path.join(data_root, rec)).p_signal[start:start + 256, 0].astype(np.float32)
        r = float(ncc(P["ecg_a"], x[None])[0])
        # 20 independent WGN draws at exactly the stated SNR; main() shows the median-result draw
        W = np.random.default_rng(0).standard_normal((20, 256)).astype(np.float32)
        Xn = x[None] + scale_noise(np.repeat(x[None], 20, 0), W, snr)
        return x, Xn, 1.0, (f"MIT-BIH record {rec}, samples {start}-{start + 255} (the paper's segment, "
                            f"corr {r:.3f}); WGN at {snr} dB, median-result draw of 20")
    S = splits_of(run)["test"]
    if ds == "eeg":
        R = json.load(open(os.path.join(run, "results.json")))
        frag = R["wave_fragment"]
        noisy, clean = corrupt(S, snr)
        return clean[frag], noisy[frag], EEG_DISPLAY, \
            f"representative test fragment {frag} (median NVMD(P) result; paper's epoch #3673 is in our training split)"
    R = json.load(open(os.path.join(run, "results.json")))
    frag = R["wave_fragment"]
    noisy, clean = corrupt(S, snr)
    disp = float(P["semg_a"].std() / clean[frag][:512].std())
    return clean[frag], noisy[frag], disp, f"synthetic stand-in test fragment {frag}"


def denoise_all(ds, run, x, xn):
    sysm, R = load_system(run)
    ks = R["kstar"]
    out = {}
    BL.BASELINE_CFG["eemd_trials"] = 20 if ds == "semg" else 50
    for dec in BL.DECOMPOSERS:
        for m in [m for m in ORDER if m.startswith(dec + "-")]:
            out[m] = BL.run_decomposer_family(dec, xn[None].astype(np.float64), ks[m], dict(VMD))[m][0][0]
    out["NVMD(P)"] = predict(sysm, ks["NVMD(P)"], xn[None], R["scale"], torch.device("cpu")).sum(1)[0]
    return out, R


# ------------------------------------------------------------------------------ MATLAB-like plot
LAYOUT = {  # pixel geometry of the paper's figures (1920 px wide)
    "ecg": dict(H=937, top=70, h=69, pitch=133.6, ylabel="Amplitude (mV)", N=256, xstep=50, legend="row"),
    "eeg": dict(H=937, top=70, h=60, pitch=133.6, ylabel="Amp (a.u.)", N=512, xstep=100, legend="col"),
    "semg": dict(H=962, top=83, h=64, pitch=137.4, ylabel="Amp (a.u.)", N=512, xstep=50, legend="col"),
}
COLX = ((250, 891), (1095, 1737))
BLUE, ORANGE = "#0072BD", "#D95319"


def draw(ds, x, xn, den, disp, path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.ticker import FuncFormatter, MaxNLocator, MultipleLocator
    plt.rcParams.update({"font.family": "Liberation Serif", "mathtext.fontset": "stix",
                         "axes.linewidth": 0.8})
    L = LAYOUT[ds]
    N = L["N"]
    W, H = 1920, L["H"]
    fig = plt.figure(figsize=(W / 100, H / 100), dpi=100)
    panels = [("(a)", x, None), ("(b)", xn, None)] + \
             [(f"({chr(ord('c') + i)})", den[m], x) for i, m in enumerate(ORDER)]
    t = np.arange(N)
    for i, (lab, y, ref) in enumerate(panels):
        row, col = divmod(i, 2)
        x0, x1 = COLX[col]
        top = L["top"] + row * L["pitch"]
        ax = fig.add_axes([x0 / W, 1 - (top + L["h"]) / H, (x1 - x0) / W, L["h"] / H])
        yy = y[:N] * disp
        if ref is not None:
            ax.plot(t, ref[:N] * disp, color=BLUE, lw=2.0, label="Original")
            ax.plot(t, yy, color=ORANGE, lw=2.0, label="Denoised")
        else:
            ax.plot(t, yy, color=BLUE, lw=2.0)
        ax.set_xlim(0, N)
        ax.xaxis.set_major_locator(MultipleLocator(L["xstep"]))
        if ds == "ecg":
            ax.set_ylim(-3, 3)
            ax.set_yticks([-2, 0, 2])
        else:
            vals = np.concatenate([yy, ref[:N] * disp]) if ref is not None else yy
            loc = MaxNLocator(nbins=4, steps=[1, 2, 2.5, 5, 10])
            tk = loc.tick_values(vals.min(), vals.max())
            ax.set_ylim(min(vals.min(), tk[1] - 0.25 * (tk[1] - tk[0])),
                        max(vals.max(), tk[-2] + 0.25 * (tk[1] - tk[0])))
            ax.yaxis.set_major_locator(MaxNLocator(nbins=4, steps=[1, 2, 2.5, 5, 10]))
            ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:g}" if abs(v) > 1e-12 else "0"))
        if ds == "semg":
            ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v * 1e3:g}" if abs(v) > 1e-12 else "0"))
            ax.text(0, 1.03, r"$\times 10^{-3}$", transform=ax.transAxes, fontsize=13, va="bottom")
        ax.grid(True, color="#DFDFDF", lw=0.8)
        ax.set_axisbelow(True)
        ax.tick_params(direction="in", top=True, right=True, labelsize=14, length=4, pad=6)
        ax.set_xlabel("Number of Samples (N)", fontsize=15, fontweight="bold", labelpad=4)
        ax.set_ylabel(L["ylabel"], fontsize=12 if ds == "ecg" else 13, fontweight="bold", labelpad=2)
        fig.text((x0 - 90) / W, 1 - (top + L["h"] / 2) / H, lab, fontsize=21, fontweight="bold",
                 ha="center", va="center")
        if ref is not None:
            kw = dict(prop={"weight": "bold", "size": 13}, frameon=True, fancybox=False,
                      edgecolor="black", framealpha=1, handlelength=2.6, borderpad=0.2,
                      labelspacing=0.1, handletextpad=0.35, borderaxespad=0)
            if L["legend"] == "row":
                lg = ax.legend(loc="upper right", ncol=2, columnspacing=0.7, **kw)
            else:
                lg = ax.legend(loc="lower right", bbox_to_anchor=(1.0, 1.0), ncol=1, **kw)
            lg.get_frame().set_linewidth(0.8)
    fig.savefig(path, dpi=150, facecolor="white")
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", default="/home/claude/runs")
    ap.add_argument("--ecg-root", default="/home/claude/data/mitdb_full")
    ap.add_argument("--out", default="/home/claude/runs/paper_style")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    AMP["dtype"] = torch.bfloat16  # same precision the models were trained/evaluated with
    torch.manual_seed(0)
    info = {}
    for ds, fig in (("ecg", 7), ("eeg", 8), ("semg", 9)):
        run = os.path.join(a.runs, f"cpu_{ds}")
        x, xn, disp, desc = example(ds, run, a.ecg_root)
        info_wgn = None
        if xn.ndim == 2:  # ECG: pick the WGN draw with the median NVMD(P) result on this segment
            sysm, R = load_system(run)
            v = snr_db(x[None], predict(sysm, R["kstar"]["NVMD(P)"], xn, R["scale"],
                                        torch.device("cpu")).sum(1)) - snr_db(x[None], xn)
            info_wgn = f"{v.mean():.2f} +/- {v.std():.2f} dB over 20 WGN draws"
            xn = xn[int(np.argsort(v)[len(v) // 2])]
        den, R = denoise_all(ds, run, x, xn)
        snr_in = float(snr_db(x[None], xn[None])[0])
        imp = {m: float(snr_db(x[None], den[m][None])[0]) - snr_in for m in ORDER}
        # where does this example sit among all test fragments at the same input SNR?
        S = splits_of(run)["test"]
        noisy, clean = corrupt(S, DATASETS[ds]["wave_snr"])
        sysm, _ = load_system(run)
        Kp = R["kstar"]["NVMD(P)"]
        dist = snr_db(clean, predict(sysm, Kp, noisy, R["scale"], torch.device("cpu")).sum(1)) - snr_db(clean, noisy)
        pct = float((dist < imp["NVMD(P)"]).mean() * 100)
        path = os.path.join(a.out, f"fig{fig}_{ds}_paper_style.png")
        draw(ds, x, xn, den, disp, path)
        info[ds] = dict(example=desc, input_snr_db=round(snr_in, 2), kstar=R["kstar"],
                        snr_imp_db={m: round(v, 2) for m, v in imp.items()},
                        nvmdp_percentile_in_test=round(pct, 1), nvmdp_same_segment_wgn=info_wgn,
                        figure=path)
        print(ds, json.dumps(info[ds], indent=1), flush=True)
    json.dump(info, open(os.path.join(a.out, "examples.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
