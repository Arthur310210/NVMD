"""Collect the headline numbers of several runs into one markdown summary."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from nvmd import paper_values as PV
from nvmd.config import DATASETS

runs = {"ecg": "cpu_ecg", "eeg": "cpu_eeg", "semg": "cpu_semg"}
root = sys.argv[1]
L = ["# NVMD reproduction — summary of the CPU-profile runs", ""]
for ds, d in runs.items():
    p = os.path.join(root, d, "results.json")
    if not os.path.exists(p):
        continue
    R = json.load(open(p))
    C, ks = R["curves"], R["kstar"]
    snrs = DATASETS[ds]["table_snrs"]
    tag = " (synthetic stand-in, not Ninapro)" if ds == "semg" else ""
    L += [f"## {ds.upper()}{tag}", "",
          f"K*: NVMD(A) {ks['NVMD(A)']}, NVMD(P) {ks['NVMD(P)']} (paper {PV.KSTAR[ds]})", "",
          "SNR_imp (dB) at K*, ours / paper:", "",
          "| Method | " + " | ".join(f"{s} dB" for s in snrs) + " |", "|---" * (len(snrs) + 1) + "|"]
    base = [m for m in PV.M[:9] if m in C]
    best = {s: max(base, key=lambda m: C[m][str(ks[m])][str(s)]["snrimp"]) for s in snrs}
    L.append("| best baseline | " + " | ".join(
        f"{C[best[s]][str(ks[best[s]])][str(s)]['snrimp']:.2f} ({best[s]}) / "
        f"{max(PV.TABLE2[ds][m][i] for m in PV.M[:9]):.2f}" for i, s in enumerate(snrs)) + " |")
    for m in ("NVMD(A)", "NVMD(P)"):
        L.append(f"| {m} | " + " | ".join(
            f"{C[m][str(ks[m])][str(s)]['snrimp']:.2f} / {PV.TABLE2[ds][m][i]}" for i, s in enumerate(snrs)) + " |")
    s45 = str(DATASETS[ds]["table45_snr"])
    L += ["", f"At {s45} dB (Tables IV/V): DDAE [33] {C['DDAE']['1'][s45]['snrimp']:.2f} dB "
          f"(paper {PV.TABLE5[ds]['DDAE']}), DDAE-F3 (extra) {C['DDAE-F3']['1'][s45]['snrimp']:.2f} dB, "
          f"NVMD(A) {C['NVMD(A)'][str(ks['NVMD(A)'])][s45]['snrimp']:.2f}, "
          f"NVMD(P) {C['NVMD(P)'][str(ks['NVMD(P)'])][s45]['snrimp']:.2f} dB.", ""]
p = os.path.join(root, "cpu_ecg_18k", "results.json")
if os.path.exists(p):
    R = json.load(open(p)); C = R["curves"]
    R6 = json.load(open(os.path.join(root, "cpu_ecg", "results.json")))["curves"]
    L += ["## ECG: does NVMD(P)'s lead over NVMD(A) grow with more training data? (K = 3)", "",
          "| input SNR | P−A, 6,000 train | P−A, 18,000 train |", "|---|---|---|"]
    for s in DATASETS["ecg"]["table_snrs"]:
        d6 = R6["NVMD(P)"]["3"][str(s)]["snrimp"] - R6["NVMD(A)"]["3"][str(s)]["snrimp"]
        d18 = C["NVMD(P)"]["3"][str(s)]["snrimp"] - C["NVMD(A)"]["3"][str(s)]["snrimp"]
        L.append(f"| {s} dB | {d6:+.2f} dB | {d18:+.2f} dB |")
    L.append("")
print("\n".join(L))
