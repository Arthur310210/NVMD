"""Check the batched VMD against the reference vmdpy implementation."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from nvmd.vmd import vmd  # noqa: E402


def test_against_vmdpy():
    from vmdpy import VMD
    rng = np.random.default_rng(0)
    N = 256
    t = np.arange(N) / 360
    sigs = np.stack([np.sin(2 * np.pi * 5 * t) + 0.5 * np.sin(2 * np.pi * 40 * t)
                     + 0.2 * rng.standard_normal(N) for _ in range(6)])
    for K in (1, 3, 5):
        ours = vmd(sigs, K, alpha=2000, tau=0, DC=False, init=1, tol=1e-7, order=None, compat="vmdpy")
        for i in range(len(sigs)):
            ref, _, _ = VMD(sigs[i], 2000, 0, K, 0, 1, 1e-7)
            err = np.max(np.abs(ours[i] - ref))
            assert err < 1e-8, (K, i, err)
    print("batched VMD matches vmdpy")


if __name__ == "__main__":
    test_against_vmdpy()
