"""Clean IMF targets u_k (Eq. 2): VMD of every clean segment for K = 1..K_max, cached on disk."""
from __future__ import annotations

import os
from concurrent.futures import ProcessPoolExecutor

import numpy as np

from .vmd import vmd


def _chunk(args):
    X, K, cfg = args
    return vmd(X, K, **cfg).astype(np.float32)


def clean_imf_targets(clean, K, vmd_cfg, path, chunk=256, n_jobs=None):
    """Returns a (M, K, N) float32 memmap of clean IMFs (computed once, then reused)."""
    if os.path.exists(path):
        return np.load(path, mmap_mode="r")
    M, N = clean.shape
    tmp = path + ".tmp.npy"
    out = np.lib.format.open_memmap(tmp, mode="w+", dtype=np.float32, shape=(M, K, N))
    starts = list(range(0, M, chunk))
    jobs = [(np.asarray(clean[s:s + chunk], np.float64), K, vmd_cfg) for s in starts]
    n_jobs = n_jobs or max(1, (os.cpu_count() or 1))
    if n_jobs == 1:
        results = map(_chunk, jobs)
    else:
        ex = ProcessPoolExecutor(n_jobs)
        results = ex.map(_chunk, jobs)
    for s, r in zip(starts, results):
        out[s:s + len(r)] = r
    out.flush()
    del out
    os.replace(tmp, path)
    return np.load(path, mmap_mode="r")
