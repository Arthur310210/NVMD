"""End-to-end reproduction of Section IV for one modality (ECG / EEG / sEMG).

Produces, in <out>/:
  results.json                 every number computed
  report.md                    Tables I-V side by side with the paper's values
  tables/*.csv                 the same tables as CSV
  figs/fig5_snrimp_vs_K.png    Fig. 5 panel for this modality
  figs/fig6_time_vs_K.png      Fig. 6 (this modality)
  figs/fig_waveforms.png       Fig. 7 / 8 / 9 for this modality
"""
from __future__ import annotations

import copy
import json
import os
import time

import numpy as np
import torch

from . import baselines as BL
from . import paper_values as PV
from .config import CPU_PROFILE, DATASETS, EVAL, QUICK, TRAIN, VMD
from .data import build_splits, corrupt, download
from .metrics import corr, imf_snr_imp, rmse, snr_db, snr_imp
from .models import DDAE, FCNDAE, NVMDSystem
from .targets import clean_imf_targets
from .train import AMP, SplitTensors, predict, set_seed, time_per_data, train_ddae, train_system

FIG_NAME = {"ecg": "Fig. 7", "eeg": "Fig. 8", "semg": "Fig. 9"}
PANEL = {"ecg": "(a)", "eeg": "(b)", "semg": "(c)"}


class Logger:
    def __init__(self, path):
        self.f = open(path, "a")

    def __call__(self, *a):
        msg = " ".join(str(x) for x in a)
        print(msg, flush=True)
        self.f.write(msg + "\n")
        self.f.flush()


def _metrics(clean, noisy, den, scale, units):
    s = scale if units == "normalized" else 1.0
    return dict(snrimp=snr_imp(clean, noisy, den), rmse=rmse(clean / s, den / s), corr=corr(clean, den))


def run(dataset, data_root, out, quick=False, device=None, synthetic=False, skip_baselines=False,
        overrides=None, do_download=False, profile=None, threads=None):
    t_start = time.time()
    os.makedirs(out, exist_ok=True)
    for d in ("cache", "ckpt", "tables", "figs"):
        os.makedirs(os.path.join(out, d), exist_ok=True)
    log = Logger(os.path.join(out, "log.txt"))
    if threads:
        torch.set_num_threads(threads)
    dcfg = copy.deepcopy(DATASETS[dataset])
    tcfg = copy.deepcopy(TRAIN)
    ecfg = copy.deepcopy(EVAL)
    sizes = None
    prof = {}
    if quick:
        prof = dict(QUICK)
    elif profile == "cpu":
        prof = dict(CPU_PROFILE[dataset])
        tcfg["amp"] = "bf16"
    for k in ("n_train", "n_val", "n_test"):
        if prof and (overrides or {}).get(k):
            prof[k] = overrides[k]
    if prof:
        sizes = (prof["n_train"], prof["n_val"], prof["n_test"])
        for k in ("epochs", "K_max", "batch_size"):
            if k in prof:
                tcfg[k] = prof[k]
        for k in ("baseline_max_test", "time_samples"):
            if k in prof:
                ecfg[k] = prof[k]
        if "eemd_trials" in prof:
            BL.BASELINE_CFG["eemd_trials"] = prof["eemd_trials"]
    for k, v in (overrides or {}).items():
        for c in (tcfg, ecfg, dcfg, BL.BASELINE_CFG):
            if k in c and v is not None:
                c[k] = v
    AMP["dtype"] = torch.bfloat16 if tcfg.get("amp") == "bf16" else None
    device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
    set_seed(tcfg["seed"])
    log(f"=== NVMD reproduction: {dataset} | profile={profile} quick={quick} | device={device} "
        f"threads={torch.get_num_threads()}")
    log("train cfg:", tcfg)
    log("eval cfg:", ecfg)
    log("vmd cfg:", VMD)
    log("baseline cfg:", BL.BASELINE_CFG)

    # ------------------------------------------------------------------ data
    if do_download:
        download(dataset, data_root)
    splits = build_splits(dataset, dcfg, data_root, os.path.join(out, "cache"), seed=tcfg["seed"],
                          sizes=sizes, synthetic=synthetic)
    for s, d in splits.items():
        log(f"{s}: {len(d['idx'])} fragments from {len(d['clean'])} clean segments, N={d['clean'].shape[1]}")
    scale = float(splits["train"]["clean"].std())
    log(f"normalisation scale (train clean std) = {scale:.6g}")

    K_max = tcfg["K_max"]
    targets = {s: {} for s in splits}
    for s in splits:
        for K in range(1, K_max + 1):
            t0 = time.time()
            p = os.path.join(out, "cache", f"targets_{s}_K{K}.npy")
            targets[s][K] = clean_imf_targets(splits[s]["clean"], K, VMD, p)
            log(f"clean IMF targets {s} K={K}: {targets[s][K].shape} ({time.time() - t0:.1f}s)")
    recon = {K: float(np.mean(snr_db(splits["test"]["clean"], np.asarray(targets["test"][K]).sum(1))))
             for K in range(1, K_max + 1)}
    log("SNR of sum of clean IMFs vs clean signal (dB):", {k: round(v, 1) for k, v in recon.items()})

    train = SplitTensors(splits["train"], targets["train"], scale)
    val = SplitTensors(splits["val"], targets["val"], scale)

    # ------------------------------------------------------------------ training
    systems = {}
    for kind in ("A", "P"):
        log(f"--- training NVMD({kind})")
        systems[kind] = train_system(NVMDSystem(kind, K_max, tcfg["group_size"], tcfg["lateral_mode"]),
                                     train, val, tcfg, device, os.path.join(out, "ckpt"), log)
    # DDAE baselines: "DDAE" = FCN-DAE of ref. [33] (the paper's comparison);
    # "DDAE-F3" = our extra ablation, one Fig. 3 encoder-decoder trained noisy -> clean.
    ck = os.path.join(out, "ckpt")
    if os.path.exists(os.path.join(ck, "ddae.pt")) and not os.path.exists(os.path.join(ck, "ddae_fig3.pt")):
        os.rename(os.path.join(ck, "ddae.pt"), os.path.join(ck, "ddae_fig3.pt"))  # old naming
    log("--- training DDAE (FCN-DAE [33])")
    ddaes = {"DDAE": train_ddae(FCNDAE(), train, val, tcfg, device, ck, log, "ddae_fcn.pt")}
    log("--- training DDAE-F3 (Fig. 3 backbone)")
    ddaes["DDAE-F3"] = train_ddae(DDAE(), train, val, tcfg, device, ck, log, "ddae_fig3.pt")

    # ------------------------------------------------------------------ evaluation
    test = splits["test"]
    eval_snrs = sorted(set(dcfg["test_snrs"]) | set(dcfg["table_snrs"])
                       | {dcfg["fig5_snr"], dcfg["table45_snr"], dcfg["wave_snr"]})
    base_snrs = sorted(set(dcfg["table_snrs"]) | {dcfg["fig5_snr"], dcfg["wave_snr"]})
    R = {"dataset": dataset, "quick": quick, "profile": profile, "eval_snrs": eval_snrs,
         "base_snrs": base_snrs, "scale": scale, "n_train": int(train.n),
         "n_test": int(len(test["idx"])), "epochs": tcfg["epochs"], "K_max": K_max,
         "imf_recon_snr": recon, "curves": {}, "time_ms": {}, "kstar": {}}
    units = ecfg["rmse_units"]
    noisy_by_snr = {snr: corrupt(test, snr) for snr in eval_snrs}

    log("--- evaluating NVMD / DDAE")
    per_frag = {}
    for kind, sysm in systems.items():
        name = f"NVMD({kind})"
        R["curves"][name] = {}
        for c in range(1, K_max + 1):
            R["curves"][name][c] = {}
            for snr in eval_snrs:
                noisy, clean = noisy_by_snr[snr]
                den = predict(sysm, c, noisy, scale, device).sum(1)
                R["curves"][name][c][snr] = _metrics(clean, noisy, den, scale, units)
                per_frag[(name, c, snr)] = snr_db(clean, den) - snr_db(clean, noisy)
        nt = noisy_by_snr[dcfg["fig5_snr"]][0][: ecfg["time_samples"]]
        R["time_ms"][name] = {c: time_per_data(sysm, c, nt, scale, device, ecfg["time_batch"])
                              for c in range(1, K_max + 1)}
    nt = noisy_by_snr[dcfg["fig5_snr"]][0][: ecfg["time_samples"]]
    for dname, net in ddaes.items():
        R["curves"][dname] = {1: {}}
        for snr in eval_snrs:
            noisy, clean = noisy_by_snr[snr]
            den = predict(net, 1, noisy, scale, device)[:, 0]
            R["curves"][dname][1][snr] = _metrics(clean, noisy, den, scale, units)
        R["time_ms"][dname] = {1: time_per_data(net, 1, nt, scale, device, ecfg["time_batch"])}

    # per-IMF analysis (Tables IV / V)
    s45 = dcfg["table45_snr"]
    noisy, clean = noisy_by_snr[s45]
    R["per_imf"] = {}
    for kind, sysm in systems.items():
        name = f"NVMD({kind})"
        R["per_imf"][name] = {}
        for c in range(1, K_max + 1):
            U = predict(sysm, c, noisy, scale, device)
            Ut = np.asarray(targets["test"][c][test["idx"]])
            R["per_imf"][name][c] = dict(
                corr=[corr(Ut[:, k], U[:, k]) for k in range(c)],
                snrimp=[imf_snr_imp(Ut[:, k], U[:, k], clean, noisy) for k in range(c)],
                overall_corr=corr(clean, U.sum(1)),
                overall_snrimp=snr_imp(clean, noisy, U.sum(1)))
    _json_dump(R, os.path.join(out, "results.json"))

    # ------------------------------------------------------------------ baselines
    nb = min(ecfg["baseline_max_test"], len(test["idx"]))
    R["n_baseline"] = nb
    if not skip_baselines:
        bpath = os.path.join(out, "cache", f"baselines_n{nb}.json")
        B = json.load(open(bpath)) if os.path.exists(bpath) else {}
        log(f"--- evaluating baselines on {nb} test fragments at SNRs {base_snrs}")
        vmd_cfg = dict(VMD)
        nts = min(ecfg["time_samples"], nb)
        for dec in BL.DECOMPOSERS:
            for K in range(1, K_max + 1):
                key = f"{dec}|{K}"
                if key in B:
                    continue
                entry = {"curves": {}, "time_ms": {}}
                for snr in base_snrs:
                    noisy, clean = noisy_by_snr[snr]
                    res = BL.run_decomposer_family(dec, noisy[:nb], K, vmd_cfg)
                    for m, (xh, _, _) in res.items():
                        entry["curves"].setdefault(m, {})[str(snr)] = _metrics(
                            clean[:nb], noisy[:nb], xh, scale, units)
                # timing: one signal at a time (batch size 1), like the networks
                noisy = noisy_by_snr[dcfg["fig5_snr"]][0]
                tsum = {}
                for i in range(nts):
                    r1 = BL.run_decomposer_family(dec, noisy[i:i + 1], K, vmd_cfg)
                    for m, (_, _, t) in r1.items():
                        tsum[m] = tsum.get(m, 0.0) + t * 1e3 / nts
                entry["time_ms"] = tsum
                B[key] = entry
                json.dump(B, open(bpath, "w"))
                log(f"  {dec} K={K} done ({time.time() - t_start:.0f}s elapsed)")
        for key, entry in B.items():
            dec, K = key.split("|")
            K = int(K)
            if K > K_max:
                continue
            for m, cur in entry["curves"].items():
                R["curves"].setdefault(m, {})[K] = {float(s) if "." in s else int(s): v
                                                    for s, v in cur.items()}
            for m, t in entry["time_ms"].items():
                R["time_ms"].setdefault(m, {})[K] = t

    # ------------------------------------------------------------------ K* (Eq. 23)
    sel = dcfg["table_snrs"]
    for m, cur in R["curves"].items():
        if m.startswith("DDAE"):
            continue
        pooled = {K: np.mean([cur[K][s]["snrimp"] for s in sel]) for K in cur}
        R["kstar"][m] = int(max(pooled, key=pooled.get))
    log("K*:", R["kstar"])

    # ------------------------------------------------------------------ outputs
    wave_idx = _representative_fragment(per_frag, R, dcfg)
    R["wave_fragment"] = wave_idx
    _json_dump(R, os.path.join(out, "results.json"))
    report = make_report(R, dcfg, dataset, out)
    make_figures(R, dcfg, dataset, out, systems, splits, scale, device, noisy_by_snr, K_max,
                 wave_idx, targets)
    with open(os.path.join(out, "report.md"), "w") as f:
        f.write(report)
    log(f"done in {time.time() - t_start:.0f}s -> {out}")
    return R


def _representative_fragment(per_frag, R, dcfg):
    """Test fragment for Figs. 7-9: the one whose NVMD(P) SNR_imp (at K*, waveform SNR) is the
    median over the test set, so the plotted example is typical rather than hand-picked."""
    K = R["kstar"]["NVMD(P)"]
    v = per_frag[("NVMD(P)", K, dcfg["wave_snr"])]
    return int(np.argsort(v)[len(v) // 2])


def _json_dump(obj, path):
    def conv(o):
        if isinstance(o, dict):
            return {str(k): conv(v) for k, v in o.items()}
        if isinstance(o, (list, tuple)):
            return [conv(v) for v in o]
        if isinstance(o, (np.floating, np.integer)):
            return o.item()
        return o
    with open(path, "w") as f:
        json.dump(conv(obj), f, indent=1)


# ============================================================================ tables
def _fmt(v, nd=3):
    return "—" if v is None else f"{v:.{nd}f}"


def _write_csv(path, header, rows):
    import csv
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def make_report(R, dcfg, ds, out):
    methods = [m for m in PV.M if m in R["curves"]]
    lines = [f"# NVMD reproduction report — {ds.upper()}", "",
             f"Profile: {R.get('profile')} | training fragments: {R.get('n_train')} | epochs: "
             f"{R.get('epochs')} | K = 1..{R.get('K_max')} | test fragments: {R['n_test']} "
             f"(NVMD/DDAE), {R.get('n_baseline')} (baselines) per SNR.", "",
             "Each cell is **ours / paper**. K* is chosen per method by Eq. (23), pooling SNR_imp "
             "over the table's SNR columns.", ""]
    lines += _claims(R, dcfg, ds)

    # Table I
    lines += ["## Table I — average computation time T_IMFs (ms/data, batch size 1, "
              f"mean over K = 1..{R.get('K_max')}; ours on a 2-core CPU)", "",
              "| Method | ours | paper |", "|---|---|---|"]
    rows = []
    for m in methods:
        if m in R["time_ms"]:
            ours = float(np.mean(list(R["time_ms"][m].values())))
            lines.append(f"| {m} | {ours:.2f} | {PV.TABLE1[ds][m]} |")
            rows.append([m, ours, PV.TABLE1[ds][m]])
    _write_csv(os.path.join(out, "tables", "table1_time.csv"), ["method", "ours_ms", "paper_ms"], rows)

    # Tables II / III
    for tab, key, pv, nd in (("II", "snrimp", PV.TABLE2, 2), ("III", "rmse", PV.TABLE3, 3)):
        snrs = dcfg["table_snrs"]
        title = "average SNR_imp (dB)" if key == "snrimp" else "average RMSE"
        lines += ["", f"## Table {tab} — {title} at K* (columns = input SNR in dB)", "",
                  "| Method | K* | " + " | ".join(f"{s} dB" for s in snrs) + " |",
                  "|---|---|" + "---|" * len(snrs)]
        rows = []
        for m in methods:
            K = R["kstar"][m]
            cells, row = [], [m, K]
            for i, s in enumerate(snrs):
                o = R["curves"][m][K][s][key]
                p = pv[ds][m][i]
                cells.append(f"{o:.{nd}f} / {p}")
                row += [o, p]
            lines.append(f"| {m} | {K} | " + " | ".join(cells) + " |")
            rows.append(row)
        hdr = ["method", "K*"] + [x for s in snrs for x in (f"ours_{s}dB", f"paper_{s}dB")]
        _write_csv(os.path.join(out, "tables", f"table{tab.lower()}_{key}.csv"), hdr, rows)

    # Tables IV / V
    for tab, key, ok, pv in (("IV", "corr", "overall_corr", PV.TABLE4), ("V", "snrimp", "overall_snrimp", PV.TABLE5)):
        lines += ["", f"## Table {tab} — per-IMF {'correlation' if key == 'corr' else 'SNR_imp (dB)'} "
                      f"at input SNR {dcfg['table45_snr']} dB", "",
                  "| Model | K | per-IMF ours | per-IMF paper | overall ours | overall paper |",
                  "|---|---|---|---|---|---|"]
        rows = []
        d = R["curves"]["DDAE"][1][dcfg["table45_snr"]]
        dv = d["corr"] if key == "corr" else d["snrimp"]
        lines.append(f"| DDAE (FCN-DAE [33]) | – | – | – | {dv:.3f} | {pv[ds]['DDAE']} |")
        rows.append(["DDAE", "", "", "", dv, pv[ds]["DDAE"]])
        if "DDAE-F3" in R["curves"]:
            d3 = R["curves"]["DDAE-F3"][1][dcfg["table45_snr"]]
            d3 = d3["corr"] if key == "corr" else d3["snrimp"]
            lines.append(f"| DDAE-F3 (Fig. 3 backbone, our extra) | – | – | – | {d3:.3f} | — |")
            rows.append(["DDAE-F3", "", "", "", d3, ""])
        for name, per in R["per_imf"].items():
            for K, v in per.items():
                pp = pv[ds].get(K)
                ours = ", ".join(f"{x:.3f}" for x in v[key])
                paper = ", ".join(str(x) for x in pp[0]) if pp else "—"
                lines.append(f"| {name} | {K} | {ours} | {paper} | {v[ok]:.3f} | {pp[1] if pp else '—'} |")
                rows.append([name, K, ours, paper, v[ok], pp[1] if pp else ""])
        _write_csv(os.path.join(out, "tables", f"table{tab.lower()}_per_imf_{key}.csv"),
                   ["model", "K", "per_imf_ours", "per_imf_paper", "overall_ours", "overall_paper"], rows)

    lines += ["", "## Optimal number of IMFs K*", "",
              f"Paper: K* = {PV.KSTAR[ds]} for NVMD. Ours: "
              + ", ".join(f"{m}: {k}" for m, k in R["kstar"].items()), ""]
    return "\n".join(lines)


def _claims(R, dcfg, ds):
    """Check the paper's qualitative claims on our numbers."""
    C = R["curves"]
    snrs = dcfg["table_snrs"]
    ks = R["kstar"]
    at = lambda m, s, key="snrimp": C[m][ks[m]][s][key]  # noqa: E731
    base = [m for m in PV.M[:9] if m in C]
    out = ["## Paper claims checked on our numbers", "",
           "| Claim (Section IV-C) | Holds? | Detail |", "|---|---|---|"]

    def row(claim, ok, detail):
        out.append(f"| {claim} | {'yes' if ok else 'no'} | {detail} |")

    pa = [at("NVMD(P)", s) - at("NVMD(A)", s) for s in snrs]
    row("NVMD(P) > NVMD(A) (SNR_imp, every table SNR)", min(pa) > 0,
        "P−A = " + ", ".join(f"{d:+.2f}" for d in pa) + " dB")
    if base:
        best = [max(at(m, s) for m in base) for s in snrs]
        da = [at("NVMD(A)", s) - b for s, b in zip(snrs, best)]
        row("NVMD(A) > best baseline (every table SNR)", min(da) > 0,
            "A−best = " + ", ".join(f"{d:+.2f}" for d in da) + " dB")
        rm = [min(at(m, s, "rmse") for m in base) for s in snrs]
        dr = [at("NVMD(P)", s, "rmse") - b for s, b in zip(snrs, rm)]
        row("NVMD(P) lowest RMSE (every table SNR)", max(dr) < 0,
            "P−best = " + ", ".join(f"{d:+.3f}" for d in dr))
        vmd_m = [m for m in base if m.startswith("VMD")]
        oth = [m for m in base if not m.startswith("VMD")]
        dv = [max(at(m, s) for m in vmd_m) - max(at(m, s) for m in oth) for s in snrs]
        row("VMD hybrids > EMD/EEMD hybrids", min(dv) > 0,
            "best VMD − best (E)EMD = " + ", ".join(f"{d:+.2f}" for d in dv) + " dB")
        if "NVMD(A)" in R["time_ms"] and "VMD-DWT" in R["time_ms"]:
            tA = np.mean(list(R["time_ms"]["NVMD(A)"].values()))
            tP = np.mean(list(R["time_ms"]["NVMD(P)"].values()))
            tV = min(np.mean(list(R["time_ms"][m].values())) for m in vmd_m)
            row("NVMD faster than VMD hybrids; A faster than P", tP < tV and tA < tP,
                f"A {tA:.1f}, P {tP:.1f}, fastest VMD hybrid {tV:.1f} ms/data")
    s45 = dcfg["table45_snr"]
    for dn, lab in (("DDAE", "DDAE (FCN-DAE [33])"), ("DDAE-F3", "DDAE-F3 (Fig. 3 backbone, extra)")):
        if dn not in C:
            continue
        dd = C[dn][1][s45]["snrimp"]
        for m in ("NVMD(A)", "NVMD(P)"):
            v = C[m][ks[m]][s45]["snrimp"]
            row(f"{m} at K* > {lab} ({s45} dB)", v > dd, f"{v:.2f} vs {dd:.2f} dB")
    row(f"K* = {PV.KSTAR[ds]}", ks["NVMD(P)"] == PV.KSTAR[ds] and ks["NVMD(A)"] == PV.KSTAR[ds],
        f"NVMD(A) K*={ks['NVMD(A)']}, NVMD(P) K*={ks['NVMD(P)']}")
    out.append("")
    return out


# ============================================================================ figures
STYLE = {"EMD-DWT": ("#1f77b4", "v"), "EMD-NLM": ("#d62728", "o"), "EMD-DWT-NLM": ("#bcbd22", "D"),
         "EEMD-DWT": ("#9467bd", "v"), "EEMD-NLM": ("#17becf", "o"), "EEMD-DWT-NLM": ("#ffbf00", "D"),
         "VMD-DWT": ("#e41a1c", "v"), "VMD-NLM": ("#0000cd", "o"), "VMD-DWT-NLM": ("#2ca02c", "P"),
         "NVMD(A)": ("#ff33cc", "*"), "NVMD(P)": ("#000000", "s")}


def make_figures(R, dcfg, ds, out, systems, splits, scale, device, noisy_by_snr, K_max,
                 wave_idx=0, targets=None):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    methods = [m for m in PV.M if m in R["curves"]]
    Ks = list(range(1, K_max + 1))

    # Fig. 5
    s5 = dcfg["fig5_snr"]
    fig, ax = plt.subplots(figsize=(7, 5.2))
    for m in methods:
        col, mk = STYLE[m]
        y = [R["curves"][m][K][s5]["snrimp"] for K in Ks]
        ls = "--" if m.startswith("NVMD") else "-"
        ax.plot(Ks, y, ls, color=col, marker=mk, label=m, lw=1.6 if m.startswith("NVMD") else 1)
    kp = int(np.argmax([R["curves"]["NVMD(P)"][K][s5]["snrimp"] for K in Ks])) + 1
    ax.annotate(f"K*={kp}", (kp, R["curves"]["NVMD(P)"][kp][s5]["snrimp"]), color="red",
                xytext=(0, -16), textcoords="offset points", ha="center")
    lo, hi = ax.get_ylim()
    ax.set_ylim(lo, hi + 0.04 * (hi - lo))
    ax.set_xlabel("Number of IMFs: K")
    ax.set_xticks(Ks)
    ax.set_ylabel("Average SNR improvement (dB)")
    ax.set_title(f"Fig. 5{PANEL[ds]} {ds.upper()}, input SNR = {s5} dB")
    ax.legend(ncol=4, fontsize=7, loc="upper center", bbox_to_anchor=(0.5, -0.14), frameon=False)
    ax.grid(alpha=.3)
    fig.tight_layout()
    fig.savefig(os.path.join(out, "figs", "fig5_snrimp_vs_K.png"), dpi=150)
    plt.close(fig)

    # Fig. 6
    fig, ax = plt.subplots(figsize=(7, 5.2))
    for m in methods:
        if m in R["time_ms"]:
            col, mk = STYLE[m]
            ax.plot(Ks, [R["time_ms"][m][K] for K in Ks], "--" if m.startswith("NVMD") else "-",
                    color=col, marker=mk, label=m)
    ax.set_xlabel("Number of IMFs: k")
    ax.set_xticks(Ks)
    ax.set_ylabel("Time consumption T(k) (ms/data)")
    ax.set_title(f"Fig. 6 ({ds.upper()})")
    ax.set_yscale("log")
    ax.legend(ncol=4, fontsize=7, loc="upper center", bbox_to_anchor=(0.5, -0.14), frameon=False)
    ax.grid(alpha=.3)
    fig.tight_layout()
    fig.savefig(os.path.join(out, "figs", "fig6_time_vs_K.png"), dpi=150)
    plt.close(fig)

    # Figs. 7-9: one test fragment, every method at its K*
    sw = dcfg["wave_snr"]
    noisy, clean = noisy_by_snr[sw]
    x, xn = clean[wave_idx:wave_idx + 1], noisy[wave_idx:wave_idx + 1]
    panels = [("(a) Original clean signal", x[0], None), (f"(b) Noisy signal, SNR {sw} dB", xn[0], None)]
    letters = "cdefghijkl"
    i = 0
    for m in methods:
        if m == "NVMD(A)":
            continue
        K = R["kstar"][m]
        if m.startswith("NVMD"):
            den = predict(systems[m[5]], K, xn, scale, device).sum(1)[0]
        else:
            den = BL.run_decomposer_family(m.split("-")[0], xn, K, dict(VMD))[m][0][0]
        so = float(snr_db(x[0], den))
        panels.append((f"({letters[i]}) {m} (K={K})  SNR_out {so:.1f} dB", den, x[0]))
        i += 1
    rows = int(np.ceil(len(panels) / 2))
    tt = np.arange(len(x[0])) / dcfg["fs"]
    fig, axes = plt.subplots(rows, 2, figsize=(12, 1.6 * rows), sharex=True)
    for a, (t, y, ref) in zip(axes.flat, panels):
        if ref is not None:
            a.plot(tt, ref, color="#1f77b4", lw=1, label="Original")
            a.plot(tt, y, color="#ff5a1f", lw=1, label="Denoised")
            a.legend(fontsize=6, loc="upper right")
        else:
            a.plot(tt, y, color="#1f77b4", lw=1)
        a.set_title(t, fontsize=8, loc="left")
        a.tick_params(labelsize=6)
    for a in axes.flat[len(panels):]:
        a.axis("off")
    for a in axes[-1]:
        a.set_xlabel("Time (s)", fontsize=7)
    fig.suptitle(f"{FIG_NAME[ds]} — denoised {ds.upper()} waveforms (input SNR {sw} dB)", fontsize=10)
    fig.tight_layout()
    fig.savefig(os.path.join(out, "figs", "fig_waveforms.png"), dpi=150)
    plt.close(fig)

    # Clean vs denoised IMFs of NVMD(P) at K* for the same fragment (cf. Fig. 4b)
    if targets is not None:
        K = R["kstar"]["NVMD(P)"]
        U = predict(systems["P"], K, xn, scale, device)[0]
        Ut = np.asarray(targets["test"][K][splits["test"]["idx"][wave_idx]])
        fig, axes = plt.subplots(K + 1, 1, figsize=(10, 1.5 * (K + 1)), sharex=True)
        for k in range(K):
            axes[k].plot(tt, Ut[k], color="#1f77b4", lw=1, label=f"clean IMF{k + 1} (VMD)")
            axes[k].plot(tt, U[k], color="#ff5a1f", lw=1, label=f"NVMD(P) IMF{k + 1}")
            axes[k].legend(fontsize=6, loc="upper right")
            axes[k].tick_params(labelsize=6)
        axes[K].plot(tt, x[0], color="#1f77b4", lw=1, label="clean signal")
        axes[K].plot(tt, U.sum(0), color="#ff5a1f", lw=1, label="sum of NVMD(P) IMFs")
        axes[K].legend(fontsize=6, loc="upper right")
        axes[K].set_xlabel("Time (s)", fontsize=7)
        fig.suptitle(f"{ds.upper()}: clean vs denoised IMFs, NVMD(P), K*={K}, input SNR {sw} dB",
                     fontsize=9)
        fig.tight_layout()
        fig.savefig(os.path.join(out, "figs", "fig_imfs_nvmdp.png"), dpi=150)
        plt.close(fig)
