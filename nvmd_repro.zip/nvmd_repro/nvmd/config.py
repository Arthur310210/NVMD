"""All settings stated in the paper, plus explicit defaults for everything it leaves out.

Items marked  # PAPER  are taken from the paper; items marked  # ASSUMED  are not specified
there and were chosen by us (see README "Unspecified details").
"""

DATASETS = {
    "ecg": dict(
        fs=360, seg_len=256,                                  # PAPER (MIT-BIH, 256 samples)
        n_frag=72000, split=(54000, 7200, 10800),             # PAPER
        train_snrs=[-6, -4, -2, 0, 2, 4, 6, 8, 10],           # PAPER
        test_snrs=[-5, -3, -1, 0, 5, 10],                     # PAPER
        table_snrs=[-5, -3, -1, 0, 5],                        # PAPER (Tables II/III columns)
        fig5_snr=1, table45_snr=-1, wave_snr=-1,              # PAPER (Fig. 5a, Tables IV/V, Fig. 7)
    ),
    "eeg": dict(
        fs=256, seg_len=512,                                  # PAPER (EEGdenoiseNet, 512 samples)
        split=(34500, 7500, 11050),                           # PAPER
        clean_split=(0.75, 0.10, 0.15),                       # ASSUMED split of clean epochs
        artifact_wgn_ratio=1.0,                               # ASSUMED artifact:WGN power ratio
        train_snrs=[-11, -9, -7, -5, -3, -1, 1, 3, 5],        # PAPER
        test_snrs=[-10, -8, -6, -4, -2, 0],                   # PAPER
        table_snrs=[-10, -8, -6, -4, -2],                     # PAPER
        fig5_snr=-5, table45_snr=-6, wave_snr=-5,             # PAPER (Fig. 5b, Tables IV/V, Fig. 8)
    ),
    "semg": dict(
        fs=2000, seg_len=2000,                                # PAPER (Ninapro DB2, 2000 samples)
        split=(157700, 19800, 100050),                        # PAPER
        train_snrs=[-14, -10, -6, -2, 2, 6],                  # PAPER
        test_snrs=[-12, -8, -4, -2, 0, 2],                    # PAPER
        table_snrs=[-14, -10, -6, -2, 2],                     # PAPER (differs from test_snrs!)
        fig5_snr=-4, table45_snr=-6, wave_snr=-2,             # PAPER (Fig. 5c, Tables IV/V, Fig. 9)
    ),
}

TRAIN = dict(
    epochs=100,          # PAPER
    lr=1e-3,             # PAPER (Adam)
    batch_size=64,       # ASSUMED
    K_max=7,             # PAPER (Figs. 5-6 go up to 7 IMFs)
    group_size=3,        # PAPER (PNN groups of 3 columns)
    lateral_mode="matched",  # ASSUMED (which branches feed which)
    keep_best="val",     # ASSUMED: keep the epoch with the lowest validation loss
    seed=0,              # ASSUMED
    amp="none",          # "bf16" = CPU/GPU bfloat16 autocast (speed only)
)

# VMD used to build the clean IMF targets and the VMD-* baselines
VMD = dict(alpha=2000.0, tau=0.0, DC=False, init=1, tol=1e-7, max_iter=500,  # ASSUMED (standard)
           order="ascending")  # ASSUMED: IMF1 = lowest centre frequency (see README)

EVAL = dict(
    kstar_select="test_pooled",  # PAPER Eq. (23): argmax of test SNR_imp (pooled over test SNRs)
    rmse_units="normalized",     # ASSUMED: RMSE on signals divided by the train-set clean std
    baseline_max_test=200,       # ASSUMED: baselines evaluated on the first N test fragments / SNR
    time_samples=200,            # ASSUMED: signals used for per-data timing
    time_batch=1,                # ASSUMED: timing with batch size 1 (ms per data)
    seed=1234,
)

# CPU profile (--profile cpu): the paper's data, splits, SNRs, architecture and optimiser, but
# random subsets of the paper's train/val/test splits, fewer epochs and a smaller K range so
# that everything fits on a 2-core CPU in a few hours. bf16 autocast is used for speed.
CPU_PROFILE = {
    "ecg": dict(n_train=6000, n_val=600, n_test=1500, epochs=20, K_max=6, batch_size=32,
                baseline_max_test=100, eemd_trials=50, time_samples=30),
    "eeg": dict(n_train=6000, n_val=600, n_test=1500, epochs=20, K_max=6, batch_size=32,
                baseline_max_test=60, eemd_trials=50, time_samples=20),
    "semg": dict(n_train=3000, n_val=400, n_test=600, epochs=15, K_max=5, batch_size=32,
                 baseline_max_test=30, eemd_trials=20, time_samples=10),
}

# Smaller settings for a fast smoke run (--quick)
QUICK = dict(n_train=1200, n_val=200, n_test=200, epochs=2, K_max=4,
             baseline_max_test=8, time_samples=8, eemd_trials=10)
