"""NVMD networks (Section III-B/C, Figs. 2-3).

Branch         : one encoder-decoder of Fig. 3 that outputs one denoised IMF.
NVMDAColumn    : NVMD(A) column c = c parallel branches (Eqs. 10-13).
NVMDPGroup     : one progressive NN of NVMD(P) holding up to 3 columns; column c has c
                 branches and receives lateral adapters W_k^(j:c) from the frozen earlier
                 columns of the same group at matching depths (Eqs. 14-17).
NVMDSystem     : all columns c = 1..K_max of NVMD(A) or NVMD(P).
DDAE           : single-branch denoising autoencoder (noisy -> clean) [33,34] (Fig. 4a).
"""
from __future__ import annotations

import math

import torch
import torch.nn as nn
import torch.nn.functional as F

ENC_CH = (32, 64, 128, 256, 512)   # Fig. 3 encoder filters (kernel 3, stride 1, MaxPool 2)
DEC_CH = (256, 128, 64, 32)        # Fig. 3 decoder filters (ConvTranspose k3, s2, p1, op1)


def _pad_to(x, mult):
    """Reflect-pad the time axis to a multiple of `mult`. x (B,1,L)."""
    L = x.shape[-1]
    Lp = int(math.ceil(L / mult) * mult)
    if Lp == L:
        return x, L
    return F.pad(x, (0, Lp - L), mode="reflect"), L


class Branch(nn.Module):
    """Encoder-decoder of Fig. 3 (one branch = one IMF).

    Fig. 3 lists 5 pooling stages but only 4 stride-2 deconvolutions before a stride-1
    output deconvolution, which cannot restore the input length. We make the output
    deconvolution stride 2 (output_padding 1) so the output length equals the input.
    """

    def __init__(self, enc_ch=ENC_CH, dec_ch=DEC_CH, slope=0.01):
        super().__init__()
        blocks = []
        cin = 1
        for ch in enc_ch:
            blocks.append(nn.Sequential(
                nn.Conv1d(cin, ch, 3, stride=1, padding=1), nn.BatchNorm1d(ch),
                nn.LeakyReLU(slope), nn.MaxPool1d(2, 2)))
            cin = ch
        for ch in dec_ch:
            blocks.append(nn.Sequential(
                nn.ConvTranspose1d(cin, ch, 3, stride=2, padding=1, output_padding=1),
                nn.BatchNorm1d(ch), nn.LeakyReLU(slope)))
            cin = ch
        self.blocks = nn.ModuleList(blocks)
        self.out = nn.ConvTranspose1d(cin, 1, 3, stride=2, padding=1, output_padding=1)  # no activation
        self.depth_channels = list(enc_ch) + list(dec_ch)
        self.factor = 2 ** len(enc_ch)

    def forward(self, x, lateral=None):
        """x (B,1,Lp). lateral: list (len = depth) of tensors added after each block."""
        feats = []
        h = x
        for d, blk in enumerate(self.blocks):
            h = blk(h)
            if lateral is not None and lateral[d] is not None:
                h = h + lateral[d]
            feats.append(h)
        return self.out(h), feats


class NVMDAColumn(nn.Module):
    def __init__(self, c):
        super().__init__()
        self.c = c
        self.branches = nn.ModuleList([Branch() for _ in range(c)])

    def forward(self, x):  # x (B, L) -> (B, c, L)
        xp, L = _pad_to(x[:, None], self.branches[0].factor)
        return torch.cat([b(xp)[0] for b in self.branches], 1)[..., :L]


class NVMDPColumn(nn.Module):
    """Column with c branches and lateral adapters from previous columns of its group.

    lateral_mode "matched": branch k receives from branch min(k, c_j) of every previous
    column j (the new last branch is fed by the last branch of earlier columns);
    "all": branch k receives from every branch of every previous column.
    Adapters are 1x1 convolutions, i.e. the matrices W_k^(j:c) in R^{n_i x n_j} of Eq. (15).
    """

    def __init__(self, c, prev_sizes, lateral_mode="matched"):
        super().__init__()
        self.c = c
        self.branches = nn.ModuleList([Branch() for _ in range(c)])
        dims = self.branches[0].depth_channels
        self.sources = []
        adapters = []
        for k in range(c):
            src = []
            for j, cj in enumerate(prev_sizes):
                if lateral_mode == "matched":
                    src.append((j, min(k, cj - 1)))
                else:
                    src.extend((j, b) for b in range(cj))
            self.sources.append(src)
            adapters.append(nn.ModuleList([
                nn.ModuleList([nn.Conv1d(d, d, 1) for d in dims]) for _ in src]))
        self.adapters = nn.ModuleList(adapters)

    def forward(self, xp, prev_feats):
        outs, feats = [], []
        for k, br in enumerate(self.branches):
            lat = None
            if self.sources[k]:
                lat = []
                for d in range(len(br.depth_channels)):
                    lat.append(sum(self.adapters[k][s][d](prev_feats[j][b][d])
                                   for s, (j, b) in enumerate(self.sources[k])))
            y, f = br(xp, lat)
            outs.append(y)
            feats.append(f)
        return torch.cat(outs, 1), feats


class NVMDPGroup(nn.Module):
    """One PNN: columns start_c .. start_c+size-1."""

    def __init__(self, start_c, size, lateral_mode="matched"):
        super().__init__()
        self.start_c = start_c
        cols = []
        for i in range(size):
            c = start_c + i
            prev = list(range(start_c, c))
            cols.append(NVMDPColumn(c, prev, lateral_mode))
        self.columns = nn.ModuleList(cols)

    def forward(self, x, col_idx):  # x (B,L) -> (B, c, L) of column col_idx (0-based in group)
        xp, L = _pad_to(x[:, None], self.columns[0].branches[0].factor)
        feats = []
        for i in range(col_idx + 1):
            out, f = self.columns[i](xp, feats)
            feats.append(f)
        return out[..., :L]


class NVMDSystem(nn.Module):
    """kind "A" or "P"; columns c = 1..K_max."""

    def __init__(self, kind, K_max=7, group_size=3, lateral_mode="matched"):
        super().__init__()
        self.kind, self.K_max, self.group_size = kind, K_max, group_size
        if kind == "A":
            self.columns = nn.ModuleList([NVMDAColumn(c) for c in range(1, K_max + 1)])
        elif kind == "P":
            groups = []
            for start in range(1, K_max + 1, group_size):
                groups.append(NVMDPGroup(start, min(group_size, K_max - start + 1), lateral_mode))
            self.groups = nn.ModuleList(groups)
        else:
            raise ValueError(kind)

    def locate(self, c):
        return (c - 1) // self.group_size, (c - 1) % self.group_size

    def forward(self, x, c):
        if self.kind == "A":
            return self.columns[c - 1](x)
        g, i = self.locate(c)
        return self.groups[g](x, i)

    def trainable_module(self, c):
        if self.kind == "A":
            return self.columns[c - 1]
        g, i = self.locate(c)
        return self.groups[g].columns[i]

    def frozen_modules(self, c):
        """Earlier columns in the same PNN group (frozen while column c trains)."""
        if self.kind == "A":
            return []
        g, i = self.locate(c)
        return [self.groups[g].columns[j] for j in range(i)]


class DDAE(nn.Module):
    """Deep denoising autoencoder baseline: noisy -> clean with one branch of Fig. 3."""

    def __init__(self):
        super().__init__()
        self.net = Branch()

    def forward(self, x, c=1):
        xp, L = _pad_to(x[:, None], self.net.factor)
        return self.net(xp)[0][..., :L]  # (B,1,L)


def count_params(m):
    return sum(p.numel() for p in m.parameters())


class FCNDAE(nn.Module):
    """FCN-based denoising autoencoder of Chiang et al. 2019 (paper ref. [33]), the DDAE baseline.

    Layer list follows the public reference implementation (fperdigon/DeepFilter, FCN_DAE):
    Conv1d k16 'same' with filters 40,20,20,20,40 (stride 2) and 1 (stride 1), ELU + BN after
    each; mirrored ConvTranspose1d 1 (s1), 40,20,20,20,40 (s2), ELU + BN; linear ConvTranspose 1 (s1).
    """

    def __init__(self, k=16):
        super().__init__()
        enc = [(1, 40, 2), (40, 20, 2), (20, 20, 2), (20, 20, 2), (20, 40, 2), (40, 1, 1)]
        dec = [(1, 1, 1), (1, 40, 2), (40, 20, 2), (20, 20, 2), (20, 20, 2), (20, 40, 2)]
        self.k = k
        self.enc = nn.ModuleList()
        for ci, co, s in enc:
            conv = nn.Conv1d(ci, co, k, stride=s, padding=(k - 2) // 2) if s == 2 else \
                nn.Conv1d(ci, co, k, stride=1, padding="same")
            self.enc.append(nn.Sequential(conv, nn.ELU(), nn.BatchNorm1d(co)))
        self.dec = nn.ModuleList()
        for ci, co, s in dec:
            self.dec.append(nn.ModuleDict(dict(
                conv=nn.ConvTranspose1d(ci, co, k, stride=s, padding=(k - 2) // 2 if s == 2 else 7),
                post=nn.Sequential(nn.ELU(), nn.BatchNorm1d(co)))))
        self.out = nn.ConvTranspose1d(40, 1, k, stride=1, padding=7)
        self.factor = 32

    @staticmethod
    def _fit(h, L):
        return h[..., :L] if h.shape[-1] >= L else F.pad(h, (0, L - h.shape[-1]))

    def forward(self, x, c=1):
        xp, L = _pad_to(x[:, None], self.factor)
        h = xp
        for blk in self.enc:
            h = blk(h)
        for blk in self.dec:
            Lt = h.shape[-1] * blk["conv"].stride[0]
            h = blk["post"](self._fit(blk["conv"](h), Lt))
        h = self._fit(self.out(h), xp.shape[-1])
        return h[..., :L]  # (B,1,L)
