"""Dataset loading, splitting and noise generation (Section IV-A).

Every split is stored as
    clean : (M, N)  unique clean segments
    idx   : (n,)    clean segment used by each fragment
    noise : (n, N)  noise *shape* of each fragment (rescaled to the requested SNR on use)
    snr   : (n,)    SNR of each training/validation fragment
For evaluation, every test fragment is re-corrupted at each requested SNR with its own
noise shape, so each SNR column of Tables II/III uses the whole test set.
"""
from __future__ import annotations

import glob
import os

import numpy as np

MITDB_RECORDS = [
    "100", "101", "102", "103", "104", "105", "106", "107", "108", "109",
    "111", "112", "113", "114", "115", "116", "117", "118", "119",
    "121", "122", "123", "124", "200", "201", "202", "203", "205",
    "207", "208", "209", "210", "212", "213", "214", "215", "217",
    "219", "220", "221", "222", "223", "228", "230", "231", "232", "233", "234",
]
EEGDN_URL = "https://raw.githubusercontent.com/ncclabsustech/EEGdenoiseNet/master/data/"


# ----------------------------------------------------------------------------- noise helpers
def scale_noise(clean, noise, snr_db):
    """Rescale noise rows so that SNR(clean, clean+noise) == snr_db exactly (Eq. 26)."""
    snr_db = np.broadcast_to(np.asarray(snr_db, dtype=np.float64), (len(clean),))
    px = np.sum(clean ** 2, axis=1)
    pn = np.maximum(np.sum(noise ** 2, axis=1), 1e-30)
    g = np.sqrt(px / (pn * 10.0 ** (snr_db / 10.0)))
    return noise * g[:, None]


def corrupt(split, snr_db=None):
    """Noisy signals of a split; snr_db=None uses each fragment's own training SNR."""
    x = split["clean"][split["idx"]]
    s = split["snr"] if snr_db is None else snr_db
    return x + scale_noise(x, split["noise"], s), x


# ----------------------------------------------------------------------------- loaders
def download(dataset, root):
    """Fetch public data (needs normal internet access)."""
    os.makedirs(root, exist_ok=True)
    if dataset == "ecg":
        import wfdb
        wfdb.dl_database("mitdb", root, records=MITDB_RECORDS)
    elif dataset == "eeg":
        import urllib.request
        for f in ("EEG_all_epochs.npy", "EOG_all_epochs.npy", "EMG_all_epochs.npy"):
            dst = os.path.join(root, f)
            if not os.path.exists(dst):
                urllib.request.urlretrieve(EEGDN_URL + f, dst)
    elif dataset == "semg":
        raise SystemExit("Ninapro DB2 requires registration: download the DB2 .mat files from "
                         "https://ninapro.hevs.ch/ and pass --data-root to the folder.")


def load_ecg(root, n_frag, seg_len, quiet=False):
    """MIT-BIH, first lead (MLII), physical units (mV); n_frag/48 segments per record."""
    import wfdb
    recs = [r for r in MITDB_RECORDS if os.path.exists(os.path.join(root, r + ".hea"))]
    if not recs:
        raise FileNotFoundError(f"No MIT-BIH records in {root}")
    if len(recs) < len(MITDB_RECORDS) and not quiet:
        print(f"[warn] only {len(recs)}/48 MIT-BIH records found in {root}")
    per_rec = int(np.ceil(n_frag / len(recs)))  # 72000 / 48 = 1500 segments per record
    segs = []
    for r in recs:
        sig = wfdb.rdrecord(os.path.join(root, r)).p_signal[:, 0]
        n = min(per_rec, len(sig) // seg_len)
        segs.append(sig[: n * seg_len].reshape(n, seg_len))
    return np.concatenate(segs)[:n_frag]


def load_eeg(root):
    eeg = np.load(os.path.join(root, "EEG_all_epochs.npy"))
    eog = np.load(os.path.join(root, "EOG_all_epochs.npy"))
    emg = np.load(os.path.join(root, "EMG_all_epochs.npy"))
    return eeg, eog, emg


def load_semg(root, seg_len):
    """Ninapro DB2: every channel of every *.mat (key 'emg', 2 kHz) cut into seg_len pieces."""
    from scipy.io import loadmat
    files = sorted(glob.glob(os.path.join(root, "**", "*.mat"), recursive=True))
    if not files:
        raise FileNotFoundError(f"No Ninapro .mat files under {root}")
    segs = []
    for f in files:
        emg = loadmat(f, variable_names=["emg"])["emg"]  # (T, 12)
        n = emg.shape[0] // seg_len
        segs.append(emg[: n * seg_len].T.reshape(emg.shape[1] * n, seg_len))
    return np.concatenate(segs)


def synthetic_semg(n, seg_len, fs, seed=0, fl=60.0, fh=120.0):
    """Physiological sEMG *stand-in* (NOT Ninapro): Gaussian noise shaped by the Shwedyk et al.
    sEMG power spectrum P(f) = fh^4 f^2 / ((f^2 + fl^2)(f^2 + fh^2)^2), band-limited 10-500 Hz,
    amplitude-modulated by smooth contraction / rest envelopes (Ninapro-style 5 s movement,
    3 s rest), cut from long continuous recordings into seg_len pieces."""
    rng = np.random.default_rng(seed)
    rec_len = 60 * fs
    n_rec = int(np.ceil(n / (rec_len // seg_len)))
    f = np.fft.rfftfreq(rec_len, 1 / fs)
    P = fh ** 4 * f ** 2 / ((f ** 2 + fl ** 2) * (f ** 2 + fh ** 2) ** 2)
    P[(f < 10) | (f > 500)] = 0
    t = np.arange(rec_len) / fs
    segs = []
    for _ in range(n_rec):
        spec = np.fft.rfft(rng.standard_normal(rec_len)) * np.sqrt(P)
        w = np.fft.irfft(spec, rec_len)
        w /= w.std()
        env = np.full(rec_len, 0.05)  # rest-level activity
        start = rng.uniform(0, 3)
        while start < t[-1]:
            dur, lvl = rng.uniform(4, 6), rng.uniform(0.3, 1.0)
            rise = 0.3
            on = np.clip((t - start) / rise, 0, 1) * np.clip((start + dur - t) / rise, 0, 1)
            env = np.maximum(env, lvl * on)
            start += dur + rng.uniform(2.5, 3.5)
        x = 0.1 * w * env  # mV scale, similar to Delsys Trigno amplitudes
        k = rec_len // seg_len
        segs.append(x[: k * seg_len].reshape(k, seg_len))
    return np.concatenate(segs)[:n]


# ----------------------------------------------------------------------------- split builders
def _sizes(cfg, sizes):
    """sizes=None -> the paper's counts; else (n_train, n_val, n_test) subsets of them."""
    return tuple(cfg["split"]) if sizes is None else tuple(sizes)


def _simple_splits(clean, cfg, rng, sizes):
    """ECG / sEMG: shuffle all fragments, split with the paper's proportions, then (optionally)
    draw random subsets of each part. Every fragment gets its own WGN shape."""
    paper = np.asarray(cfg["split"], float)
    perm = rng.permutation(len(clean))
    cuts = np.floor(np.cumsum(paper / paper.sum())[:2] * len(clean)).astype(int)
    parts = np.split(perm, cuts)
    want = _sizes(cfg, sizes)
    out = {}
    for name, ids, n in zip(("train", "val", "test"), parts, want):
        if n < len(ids):
            ids = rng.choice(ids, n, replace=False)
        elif n > len(ids):
            print(f"[warn] {name}: only {len(ids)} fragments available (wanted {n})")
        x = clean[np.sort(ids)]
        snrs = np.asarray(cfg["test_snrs"] if name == "test" else cfg["train_snrs"], float)
        snr = np.resize(snrs, len(x)) if name == "test" else rng.choice(snrs, len(x))
        out[name] = dict(clean=x, idx=np.arange(len(x)), noise=rng.standard_normal(x.shape), snr=snr)
    return out


def _eeg_splits(eeg, eog, emg, cfg, rng, sizes):
    """EEGdenoiseNet: clean epochs + (EOG or EMG artifact) + additional WGN.
    Clean and artifact epochs are split 75/10/15 *before* mixing (no epoch leaks to test)."""
    n_counts = _sizes(cfg, sizes)
    fr = cfg["clean_split"]

    def cut(a):
        p = rng.permutation(len(a))
        i1, i2 = int(fr[0] * len(a)), int((fr[0] + fr[1]) * len(a))
        return a[p[:i1]], a[p[i1:i2]], a[p[i2:]]

    E, O, M = cut(eeg), cut(eog), cut(emg)
    out = {}
    for s, name in enumerate(("train", "val", "test")):
        n = n_counts[s]
        clean = E[s]
        idx = rng.integers(0, len(clean), n)
        use_eog = rng.random(n) < 0.5
        art = np.where(use_eog[:, None], O[s][rng.integers(0, len(O[s]), n)],
                       M[s][rng.integers(0, len(M[s]), n)])
        art = art / art.std(axis=1, keepdims=True)
        w = rng.standard_normal(art.shape)
        r = cfg["artifact_wgn_ratio"]
        noise = np.sqrt(r / (1 + r)) * art + np.sqrt(1 / (1 + r)) * w
        snrs = np.asarray(cfg["test_snrs"] if name == "test" else cfg["train_snrs"], float)
        snr = np.resize(snrs, n) if name == "test" else rng.choice(snrs, n)
        out[name] = dict(clean=clean, idx=idx, noise=noise, snr=snr)
    return out


def build_splits(dataset, cfg, root, cache_dir, seed=0, sizes=None, synthetic=False):
    os.makedirs(cache_dir, exist_ok=True)
    tag = "paper" if sizes is None else "x".join(map(str, sizes))
    path = os.path.join(cache_dir, f"splits_{dataset}_{tag}{'_synth' if synthetic else ''}.npz")
    if os.path.exists(path):
        z = np.load(path)
        return {s: {k: z[f"{s}_{k}"] for k in ("clean", "idx", "noise", "snr")}
                for s in ("train", "val", "test")}
    rng = np.random.default_rng(seed)
    if dataset == "ecg":
        clean = load_ecg(root, cfg["n_frag"], cfg["seg_len"])   # full 72,000-fragment pool
        splits = _simple_splits(clean, cfg, rng, sizes)
    elif dataset == "eeg":
        splits = _eeg_splits(*load_eeg(root), cfg, rng, sizes)
    elif dataset == "semg":
        if synthetic:
            frac = np.asarray(cfg["split"], float) / sum(cfg["split"])
            n = int(np.ceil(max(np.asarray(_sizes(cfg, sizes)) / frac))) + 10
            clean = synthetic_semg(n, cfg["seg_len"], cfg["fs"], seed)
        else:
            clean = load_semg(root, cfg["seg_len"])
        splits = _simple_splits(clean, cfg, rng, sizes)
    else:
        raise ValueError(dataset)
    for s in splits.values():
        s["clean"] = s["clean"].astype(np.float32)
        s["noise"] = s["noise"].astype(np.float32)
    np.savez(path, **{f"{s}_{k}": v for s, d in splits.items() for k, v in d.items()})
    return splits
