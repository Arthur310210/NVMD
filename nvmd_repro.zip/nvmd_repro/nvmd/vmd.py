"""Batched Variational Mode Decomposition (Dragomiretskiy & Zosso, 2014), paper Eqs. (6)-(7).

This is a vectorised port of the reference MATLAB/vmdpy ADMM solver. Many signals are
decomposed at once; each signal keeps its own convergence test, so the result for every
signal is numerically identical to running the reference solver on it alone
(verified in tests/test_vmd.py against vmdpy).
"""
from __future__ import annotations

import numpy as np


def vmd(signals, K, alpha=2000.0, tau=0.0, DC=False, init=1, tol=1e-7,
        max_iter=500, order="ascending", seed=0, return_omega=False, compat="matlab"):
    """Decompose signals into K modes.

    Parameters
    ----------
    signals : array (N,) or (B, N)
    K : number of modes
    alpha, tau, DC, init, tol : standard VMD parameters (see vmdpy)
    max_iter : maximum ADMM iterations (reference solver uses 500)
    order : "ascending" sorts modes by centre frequency (low -> high),
            "descending" (high -> low), or None to keep solver order.
    compat : "matlab" returns the last ADMM iterate (as the original MATLAB code);
             "vmdpy" returns the second-to-last iterate, reproducing an off-by-one in
             the popular vmdpy package (only useful for cross-checking).

    Returns
    -------
    u : array (B, K, N) (or (K, N) for 1-D input)
    omega : (B, K) centre frequencies (normalised, cycles/sample) if return_omega
    """
    x = np.asarray(signals, dtype=np.float64)
    squeeze = x.ndim == 1
    if squeeze:
        x = x[None]
    B, N0 = x.shape
    odd = N0 % 2 == 1
    if odd:  # reference implementation drops the last sample of odd-length input
        x = x[:, :-1]
    N = x.shape[1]
    half = N // 2

    # mirror extension
    f_mirr = np.concatenate([x[:, :half][:, ::-1], x, x[:, -half:][:, ::-1]], axis=1)
    T = f_mirr.shape[1]
    t = np.arange(1, T + 1) / T
    freqs = t - 0.5 - 1.0 / T

    f_hat = np.fft.fftshift(np.fft.fft(f_mirr, axis=1), axes=1)
    f_hat_plus = f_hat.copy()
    f_hat_plus[:, : T // 2] = 0

    omega = np.zeros((B, K))
    if init == 1:
        omega[:] = (0.5 / K) * np.arange(K)
    elif init == 2:
        fs = 1.0 / N
        rng = np.random.default_rng(seed)
        omega = np.sort(np.exp(np.log(fs) + (np.log(0.5) - np.log(fs)) * rng.random((B, K))), axis=1)
    if DC:
        omega[:, 0] = 0.0

    u_hat = np.zeros((B, T, K), dtype=complex)
    u_prev = np.zeros((B, T, K), dtype=complex)
    lam = np.zeros((B, T), dtype=complex)
    sum_uk = np.zeros((B, T), dtype=complex)
    pos = slice(T // 2, T)
    fpos = freqs[pos]
    eps = np.spacing(1)

    active = np.arange(B)
    n = 0
    while active.size and n < max_iter - 1:
        u_old = u_hat[active]
        u_new = np.empty_like(u_old)
        om = omega[active].copy()
        lm = lam[active]
        su = sum_uk[active]
        fh = f_hat_plus[active]
        for k in range(K):
            if k == 0:
                su = u_old[:, :, K - 1] + su - u_old[:, :, 0]
            else:
                su = u_new[:, :, k - 1] + su - u_old[:, :, k]
            u_new[:, :, k] = (fh - su - lm / 2) / (1.0 + alpha * (freqs[None, :] - om[:, k:k + 1]) ** 2)
            if k > 0 or not DC:
                p = np.abs(u_new[:, pos, k]) ** 2
                den = p.sum(1)
                ok = den > 0
                om[ok, k] = (p[ok] @ fpos) / den[ok]
        lm = lm + tau * (u_new.sum(axis=2) - fh)
        diff = eps + (1.0 / T) * np.sum(np.abs(u_new - u_old) ** 2, axis=(1, 2))
        u_prev[active] = u_old
        u_hat[active] = u_new
        omega[active] = om
        lam[active] = lm
        sum_uk[active] = su
        n += 1
        active = active[diff > tol]

    if compat == "vmdpy":
        u_hat = u_prev

    # signal reconstruction (Hermitian completion)
    u_full = np.zeros((B, T, K), dtype=complex)
    u_full[:, T // 2:, :] = u_hat[:, T // 2:, :]
    idxs = np.arange(1, T // 2 + 1)[::-1]
    u_full[:, idxs, :] = np.conj(u_hat[:, T // 2:, :])
    u_full[:, 0, :] = np.conj(u_full[:, -1, :])
    u = np.real(np.fft.ifft(np.fft.ifftshift(u_full, axes=1), axis=1))
    u = u[:, T // 4: 3 * T // 4, :].transpose(0, 2, 1)  # (B, K, N)

    if order is not None:
        idx = np.argsort(omega, axis=1)
        if order == "descending":
            idx = idx[:, ::-1]
        u = np.take_along_axis(u, idx[:, :, None], axis=1)
        omega = np.take_along_axis(omega, idx, axis=1)

    if odd:
        u = np.concatenate([u, u[:, :, -1:]], axis=2)
    if squeeze:
        u, omega = u[0], omega[0]
    return (u, omega) if return_omega else u
