"""Evaluation criteria of Section IV-B (Eqs. 25-31). All functions work on (D, N) arrays."""
import numpy as np


def snr_db(ref, est):
    """Per-signal SNR of `est` with respect to `ref` (Eqs. 26/27)."""
    num = np.sum(ref ** 2, axis=-1)
    den = np.maximum(np.sum((est - ref) ** 2, axis=-1), 1e-30)
    return 10.0 * np.log10(num / den)


def snr_imp(clean, noisy, denoised):
    """Eq. (25): mean over signals of SNR_out - SNR_in."""
    return float(np.mean(snr_db(clean, denoised) - snr_db(clean, noisy)))


def imf_snr_imp(u_clean, u_hat, clean, noisy):
    """Per-IMF improvement used in Table V: SNR(u_k, u_hat_k) - SNR_in(x, x_noisy)."""
    return float(np.mean(snr_db(u_clean, u_hat) - snr_db(clean, noisy)))


def rmse(clean, denoised):
    """Eq. (28): mean over signals of the per-signal RMSE."""
    return float(np.mean(np.sqrt(np.mean((denoised - clean) ** 2, axis=-1))))


def corr(a, b):
    """Eqs. (30)-(31): mean over signals of the Pearson correlation coefficient."""
    a = a - a.mean(-1, keepdims=True)
    b = b - b.mean(-1, keepdims=True)
    den = np.sqrt(np.sum(a ** 2, -1) * np.sum(b ** 2, -1))
    return float(np.mean(np.sum(a * b, -1) / np.maximum(den, 1e-30)))
