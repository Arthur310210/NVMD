"""Training of NVMD(A), NVMD(P) (Section III-C, Eq. 19) and the DDAE baseline."""
from __future__ import annotations

import copy
import os
import time

import numpy as np
import torch

from .data import corrupt


AMP = {"dtype": None}  # set to torch.bfloat16 to enable autocast


def autocast(device):
    dt = AMP["dtype"]
    return torch.autocast(device.type, dtype=dt, enabled=dt is not None)


def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)


def l1_imf_loss(pred, target):
    """Eq. (19): sum over IMFs of the L1 error (averaged over batch and time)."""
    return (pred - target).abs().mean(dim=(0, 2)).sum()


class SplitTensors:
    """Noisy inputs and clean IMF targets of one split, normalised by `scale`."""

    def __init__(self, split, targets_by_K, scale):
        noisy, clean = corrupt(split)
        self.noisy = torch.from_numpy((noisy / scale).astype(np.float32))
        self.clean = torch.from_numpy((clean / scale).astype(np.float32))
        self.idx = split["idx"]
        self.targets_by_K = targets_by_K
        self.scale = scale
        self.n = len(self.idx)

    def targets(self, K, rows):
        t = np.asarray(self.targets_by_K[K][self.idx[rows]], dtype=np.float32)
        return torch.from_numpy(t / self.scale)


def _run_epoch(model_fn, data, K, rows, opt, device, bs, target_fn):
    total, count = 0.0, 0
    for s in range(0, len(rows), bs):
        r = rows[s:s + bs]
        x = data.noisy[r].to(device)
        y = target_fn(data, K, r).to(device)
        if opt is not None:
            opt.zero_grad(set_to_none=True)
            with autocast(device):
                pred = model_fn(x)
            loss = l1_imf_loss(pred.float(), y)
            loss.backward()
            opt.step()
        else:
            with torch.no_grad(), autocast(device):
                pred = model_fn(x)
            loss = l1_imf_loss(pred.float(), y)
        total += loss.item() * len(r)
        count += len(r)
    return total / max(count, 1)


def train_column(system, c, train, val, cfg, device, log=print, target_fn=None):
    """Train column c of an NVMDSystem (earlier columns of a PNN group stay frozen)."""
    target_fn = target_fn or (lambda d, K, r: d.targets(K, r))
    module = system.trainable_module(c)
    frozen = system.frozen_modules(c)
    for m in frozen:
        for p in m.parameters():
            p.requires_grad_(False)
    for p in module.parameters():
        p.requires_grad_(True)
    opt = torch.optim.Adam(module.parameters(), lr=cfg["lr"])
    rng = np.random.default_rng(cfg["seed"] + c)
    best, best_state = np.inf, None
    model_fn = lambda x: system(x, c)  # noqa: E731
    for ep in range(cfg["epochs"]):
        t0 = time.time()
        module.train()
        for m in frozen:
            m.eval()
        tr = _run_epoch(model_fn, train, c, rng.permutation(train.n), opt, device,
                        cfg["batch_size"], target_fn)
        module.eval()
        va = _run_epoch(model_fn, val, c, np.arange(val.n), None, device,
                        _infer_bs(val.noisy.shape[-1]), target_fn)
        if va < best:
            best, best_state = va, copy.deepcopy(module.state_dict())
        log(f"  [{system.kind} c={c}] epoch {ep + 1}/{cfg['epochs']} train {tr:.4f} val {va:.4f} "
            f"({time.time() - t0:.1f}s)")
    if cfg.get("keep_best", "val") == "val" and best_state is not None:
        module.load_state_dict(best_state)
    module.eval()
    for p in module.parameters():
        p.requires_grad_(False)
    return best


def train_system(system, train, val, cfg, device, ckpt_dir, log=print):
    os.makedirs(ckpt_dir, exist_ok=True)
    system.to(device)
    for c in range(1, system.K_max + 1):
        path = os.path.join(ckpt_dir, f"nvmd{system.kind}_col{c}.pt")
        mod = system.trainable_module(c)
        if os.path.exists(path):
            mod.load_state_dict(torch.load(path, map_location=device))
            mod.eval()
            for p in mod.parameters():
                p.requires_grad_(False)
            log(f"  [{system.kind} c={c}] loaded {path}")
            continue
        train_column(system, c, train, val, cfg, device, log)
        torch.save(mod.state_dict(), path)
    system.eval()
    return system


class _DDAEWrap:
    """Lets the DDAE reuse train_column (single 'column' whose target is the clean signal)."""

    def __init__(self, net):
        self.net, self.kind, self.K_max = net, "DDAE", 1

    def __call__(self, x, c):
        return self.net(x)

    def trainable_module(self, c):
        return self.net

    def frozen_modules(self, c):
        return []


def train_ddae(net, train, val, cfg, device, ckpt_dir, log=print, fname="ddae.pt"):
    path = os.path.join(ckpt_dir, fname)
    net.to(device)
    if os.path.exists(path):
        net.load_state_dict(torch.load(path, map_location=device))
    else:
        tf = lambda d, K, r: d.clean[r][:, None]  # noqa: E731
        train_column(_DDAEWrap(net), 1, train, val, cfg, device, log, target_fn=tf)
        torch.save(net.state_dict(), path)
    net.eval()
    return net


def _infer_bs(L):
    """Inference batch size scaled with signal length (512 for 256 samples, 64 for 2000)."""
    return max(16, 131072 // L)


@torch.no_grad()
def predict(model, c, noisy, scale, device, bs=None):
    """noisy (n,N) in original units -> IMFs (n,c,N) in original units."""
    bs = bs or _infer_bs(noisy.shape[-1])
    outs = []
    for s in range(0, len(noisy), bs):
        x = torch.from_numpy((noisy[s:s + bs] / scale).astype(np.float32)).to(device)
        with autocast(device):
            outs.append(model(x, c).float().cpu().numpy())
    return np.concatenate(outs) * scale


@torch.no_grad()
def time_per_data(model, c, noisy, scale, device, batch=1, warmup=3):
    """Average test-stage time (ms) per signal for column c (T^(k) in Fig. 6)."""
    x = torch.from_numpy((noisy / scale).astype(np.float32)).to(device)
    with autocast(device):
        for i in range(min(warmup, len(x))):
            model(x[i:i + batch], c)
    if device.type == "cuda":
        torch.cuda.synchronize()
    t0 = time.perf_counter()
    with autocast(device):
        for s in range(0, len(x), batch):
            model(x[s:s + batch], c)
    if device.type == "cuda":
        torch.cuda.synchronize()
    return (time.perf_counter() - t0) / len(x) * 1e3
