"""Non-learning baselines of Tables I-III: {EMD, EEMD, VMD} x {DWT, NLM, DWT-NLM}.

Every baseline follows the same recipe:
  1. decompose the noisy signal into exactly K components (EMD / EEMD / VMD),
  2. denoise every component (DWT soft thresholding [12,19,23], non-local means [8,9,25],
     or DWT followed by NLM [26]),
  3. sum the denoised components.

The paper does not give wavelet, level, threshold rule, NLM patch/search sizes or the EEMD
ensemble size; the defaults below are the usual choices of the cited references and are all
exposed in BASELINE_CFG.
"""
from __future__ import annotations

import time
import warnings

import numpy as np
import pywt

from .vmd import vmd

BASELINE_CFG = dict(
    wavelet="sym8",          # DWT wavelet
    dwt_level=4,             # decomposition level (capped by the signal length)
    threshold="soft",        # soft universal threshold (Donoho), sigma = MAD/0.6745
    nlm_patch=10,            # NLM patch half-width P (Tracey & Miller [8])
    nlm_search=64,           # NLM search half-width M
    nlm_lambda=0.6,          # NLM bandwidth = nlm_lambda * sigma_noise
    eemd_trials=50,          # EEMD ensemble size
    eemd_noise_width=0.2,    # EEMD added-noise std (relative to signal std)
)

DECOMPOSERS = ("EMD", "EEMD", "VMD")
POSTS = ("DWT", "NLM", "DWT-NLM")
METHODS = tuple(f"{d}-{p}" for d in DECOMPOSERS for p in POSTS)


# ----------------------------------------------------------------------------- decomposition
def _to_k_components(comps, K, N):
    """EMD-type output (high->low freq, residue last) -> exactly K components, low->high."""
    comps = [c for c in comps]
    if len(comps) > K:  # merge the slowest components into one
        comps = comps[: K - 1] + [np.sum(comps[K - 1:], axis=0)]
    while len(comps) < K:
        comps.append(np.zeros(N))
    return np.stack(comps[::-1])


def emd_k(x, K):
    from PyEMD import EMD
    emd = EMD()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        emd.emd(x, max_imf=max(K - 1, 0) if K > 1 else 1)
        imfs, res = emd.get_imfs_and_residue()
    if K == 1:
        return x[None].copy()
    return _to_k_components(list(imfs) + [res], K, len(x))


def eemd_k(x, K, trials, noise_width, seed=0):
    from PyEMD import EEMD
    if K == 1:
        return x[None].copy()
    eemd = EEMD(trials=trials, noise_width=noise_width, parallel=False)
    eemd.noise_seed(seed)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        imfs = eemd.eemd(x, max_imf=K - 1)
    res = x - imfs.sum(0)
    return _to_k_components(list(imfs) + [res], K, len(x))


def decompose(name, X, K, cfg=BASELINE_CFG, vmd_cfg=None):
    """X (B, N) -> (B, K, N)."""
    X = np.atleast_2d(X)
    if name == "VMD":
        return vmd(X, K, **(vmd_cfg or {}))
    if name == "EMD":
        return np.stack([emd_k(x, K) for x in X])
    if name == "EEMD":
        return np.stack([eemd_k(x, K, cfg["eemd_trials"], cfg["eemd_noise_width"], seed=i)
                         for i, x in enumerate(X)])
    raise ValueError(name)


# ----------------------------------------------------------------------------- denoisers
def noise_sigma(X, wavelet="db1"):
    """Robust noise std per row from finest-scale detail coefficients (MAD / 0.6745)."""
    d = pywt.wavedec(X, wavelet, level=1, axis=-1)[-1]
    return np.median(np.abs(d), axis=-1, keepdims=True) / 0.6745


def dwt_denoise(X, cfg=BASELINE_CFG):
    X = np.atleast_2d(X)
    N = X.shape[-1]
    w = pywt.Wavelet(cfg["wavelet"])
    level = max(1, min(cfg["dwt_level"], pywt.dwt_max_level(N, w.dec_len)))
    coeffs = pywt.wavedec(X, w, level=level, axis=-1)
    sigma = np.median(np.abs(coeffs[-1]), axis=-1, keepdims=True) / 0.6745
    thr = sigma * np.sqrt(2.0 * np.log(N))
    out = [coeffs[0]]
    for c in coeffs[1:]:
        if cfg["threshold"] == "soft":
            out.append(np.sign(c) * np.maximum(np.abs(c) - thr, 0.0))
        else:
            out.append(c * (np.abs(c) > thr))
    return pywt.waverec(out, w, axis=-1)[..., :N]


def nlm_denoise(X, cfg=BASELINE_CFG, sigma=None):
    """1-D non-local means (Tracey & Miller [8]); batched over rows."""
    X = np.atleast_2d(X).astype(np.float64)
    B, N = X.shape
    P = cfg["nlm_patch"]
    M = min(cfg["nlm_search"], N - 1)
    if sigma is None:
        sigma = noise_sigma(X)
    lam = np.maximum(cfg["nlm_lambda"] * sigma, 1e-12)  # (B,1)
    L = 2 * P + 1
    pad = M + P
    Xp = np.pad(X, ((0, 0), (pad, pad)), mode="symmetric")
    centre = Xp[:, M: M + N + 2 * P]
    num = np.zeros((B, N))
    den = np.zeros((B, N))
    for d in range(-M, M + 1):
        shifted = Xp[:, M + d: M + d + N + 2 * P]
        cs = np.cumsum(np.pad((centre - shifted) ** 2, ((0, 0), (1, 0))), axis=1)
        dist = cs[:, L:] - cs[:, :-L]  # (B, N)
        w = np.exp(-dist / (2.0 * L * lam ** 2))
        num += w * shifted[:, P: P + N]
        den += w
    return num / den


def post_process(name, C):
    """Denoise each component. C (B, K, N) -> (B, K, N)."""
    B, K, N = C.shape
    flat = C.reshape(B * K, N)
    if name == "DWT":
        out = dwt_denoise(flat)
    elif name == "NLM":
        out = nlm_denoise(flat)
    elif name == "DWT-NLM":
        out = nlm_denoise(dwt_denoise(flat))
    else:
        raise ValueError(name)
    return out.reshape(B, K, N)


def run_decomposer_family(decomposer, X, K, vmd_cfg=None):
    """Runs one decomposer once and all three post-processors on it.

    Returns {method: (x_hat (B,N), comps (B,K,N), seconds_per_signal)}.
    The time of a method = decomposition time + its own post-processing time.
    """
    t0 = time.perf_counter()
    C = decompose(decomposer, X, K, vmd_cfg=vmd_cfg)
    t_dec = time.perf_counter() - t0
    out = {}
    for post in POSTS:
        t1 = time.perf_counter()
        D = post_process(post, C)
        xh = D.sum(1)
        t_post = time.perf_counter() - t1
        out[f"{decomposer}-{post}"] = (xh, D, (t_dec + t_post) / len(X))
    return out
